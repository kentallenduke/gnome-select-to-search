#!/usr/bin/env gjs
// Resident helper. One process, one saved login, a bottom sheet.

imports.gi.versions.Gtk = '4.0';
imports.gi.versions.Gdk = '4.0';

const {GLib, Gio, Gtk, Gdk} = imports.gi;

const GEMINI = 'https://gemini.google.com/app';

GLib.set_prgname('circle-to-search-gemini');

const app = new Gtk.Application({
    application_id: 'org.gnome.circle_to_search.GeminiMenu',
    flags: Gio.ApplicationFlags.HANDLES_COMMAND_LINE,
});

let win = null;
let view = null;
let imagePath = '';
let searchId = 0;

app.connect('startup', () => app.hold());

app.connect('command-line', (application, commandLine) => {
    const next = imageArg(commandLine.get_arguments());
    try {
        if (!win)
            build(application);
        if (next)
            submitImage(next);
        else
            reveal();
    } catch (error) {
        printerr(error);
        if (win)
            showError(String(error));
    }
    return 0;
});

function imageArg(args) {
    for (let i = args.length - 1; i >= 0; i--) {
        const arg = args[i] || '';
        if (arg.endsWith('.png'))
            return arg;
    }
    return '';
}

function enableDrag(widget) {
    try {
        widget.set_cursor(Gdk.Cursor.new_from_name('grab', null));
    } catch (error) {
        printerr(error);
    }
    const drag = new Gtk.GestureDrag();
    drag.set_button(1);
    widget.add_controller(drag);
    drag.connect('drag-begin', gesture => {
        try {
            const surface = widget.get_native()?.get_surface();
            const event = gesture.get_current_event();
            if (!surface?.begin_move || !event)
                return;
            const [, x, y] = event.get_position();
            surface.begin_move(
                event.get_device(),
                event.get_button?.() || 1,
                x,
                y,
                event.get_time());
        } catch (error) {
            printerr(error);
        }
    });
}

function build(application) {
    win = new Gtk.ApplicationWindow({
        application,
        title: 'Select to Search',
        decorated: false,
        resizable: false,
    });
    win.add_css_class('cts-sheet');
    win.set_overflow(Gtk.Overflow.HIDDEN);
    installCss();
    watchTheme();

    const menu = new Gtk.Box({
        orientation: Gtk.Orientation.VERTICAL,
        spacing: 6,
    });
    menu.add_css_class('cts-menu');
    menu.set_overflow(Gtk.Overflow.HIDDEN);
    const bar = new Gtk.Box({
        orientation: Gtk.Orientation.HORIZONTAL,
        spacing: 8,
    });
    const icon = new Gtk.Image({pixel_size: 22});
    icon.add_css_class('cts-appicon');
    const iconFile = Gio.File.new_for_path(GLib.build_filenamev([
        GLib.get_user_data_dir(), 'icons', 'hicolor', 'scalable', 'apps',
        'org.gnome.circle_to_search.GeminiMenu.svg']));
    if (iconFile.query_exists(null))
        icon.set_from_file(iconFile.get_path());
    else
        icon.icon_name = 'edit-find-symbolic';
    const name = new Gtk.Label({label: 'Select to Search', xalign: 0});
    name.add_css_class('cts-name');
    const spacer = new Gtk.Box({hexpand: true});
    const pin = new Gtk.ToggleButton({icon_name: 'view-pin-symbolic'});
    pin.add_css_class('cts-close');
    pin.add_css_class('cts-pin');
    pin.add_css_class('flat');
    pin.set_tooltip_text('Keep above other windows, on every workspace');
    pin.set_active(readPinned());
    pin.connect('toggled', () => writePinned(pin.get_active()));
    const close = new Gtk.Button({icon_name: 'window-close-symbolic'});
    close.add_css_class('cts-close');
    close.add_css_class('flat');
    close.connect('clicked', () => win.hide());
    bar.append(icon);
    bar.append(name);
    bar.append(spacer);
    bar.append(pin);
    bar.append(close);
    enableDrag(icon);
    enableDrag(name);
    enableDrag(spacer);

    const clip = new Gtk.Box({orientation: Gtk.Orientation.VERTICAL});
    clip.add_css_class('cts-clip');
    clip.set_overflow(Gtk.Overflow.HIDDEN);
    clip.set_vexpand(true);
    clip.set_hexpand(true);
    menu.append(bar);
    menu.append(clip);
    win._root = menu;
    win._clip = clip;
    win.set_child(menu);

    const keys = new Gtk.EventControllerKey();
    keys.connect('key-pressed', (_controller, keyval) => {
        if (keyval === Gdk.KEY_Escape) {
            win.hide();
            return true;
        }
        return false;
    });
    win.add_controller(keys);
    win.connect('close-request', () => {
        win.hide();
        return true;
    });

    try {
        view = makeView();
        view.set_vexpand(true);
        view.set_hexpand(true);
        view.set_opacity(1);
        win._clip.append(view);
        installCss();
        view.load_uri(GEMINI);
    } catch (error) {
        printerr(error);
        showError(String(error));
    }
    reveal();
}

function showError(message) {
    const label = new Gtk.Label({
        label: message,
        wrap: true,
        margin_top: 12,
        margin_bottom: 16,
        margin_start: 16,
        margin_end: 16,
    });
    label.set_vexpand(true);
    win._root.append(label);
}

function reveal() {
    const geo = monitorGeometry();
    const height = Math.min(760, Math.max(560, geo.height - 88));
    win.set_default_size(432, height);
    win.present();
}

function monitorGeometry() {
    try {
        const monitors = Gdk.Display.get_default().get_monitors();
        let best = null;
        let area = 0;
        for (let i = 0; i < monitors.get_n_items(); i++) {
            const geo = monitors.get_item(i).get_geometry();
            if (geo.width * geo.height > area) {
                best = geo;
                area = geo.width * geo.height;
            }
        }
        if (best)
            return best;
    } catch (error) {
        printerr(error);
    }
    return {width: 1280, height: 800};
}

function anchorBottomRight(window) {
    try {
        imports.gi.versions.Gtk4LayerShell = '1.0';
        const Layer = imports.gi.Gtk4LayerShell;
        Layer.init_for_window(window);
        Layer.set_layer(window, Layer.Layer.OVERLAY);
        Layer.set_anchor(window, Layer.Edge.BOTTOM, true);
        Layer.set_anchor(window, Layer.Edge.RIGHT, true);
        Layer.set_anchor(window, Layer.Edge.TOP, false);
        Layer.set_anchor(window, Layer.Edge.LEFT, false);
        Layer.set_margin(window, Layer.Edge.BOTTOM, 12);
        Layer.set_margin(window, Layer.Edge.RIGHT, 8);
        Layer.set_keyboard_mode(window, Layer.KeyboardMode.ON_DEMAND);
        Layer.set_namespace(window, 'circle-to-search');
    } catch (error) {
        printerr(`Select to Search: bottom-right anchor unavailable: ${error}`);
    }
}

function makeView() {
    imports.gi.versions.WebKit = '6.0';
    const WebKit = imports.gi.WebKit;
    const dataDir = GLib.build_filenamev([
        GLib.get_user_data_dir(), 'circle-to-search', 'gemini']);
    const cacheDir = GLib.build_filenamev([
        GLib.get_user_cache_dir(), 'circle-to-search', 'gemini']);
    GLib.mkdir_with_parents(dataDir, 0o700);
    GLib.mkdir_with_parents(cacheDir, 0o700);

    let session;
    try {
        session = new WebKit.NetworkSession({
            data_directory: dataDir,
            cache_directory: cacheDir,
        });
    } catch (error) {
        session = new WebKit.NetworkSession(dataDir, cacheDir);
    }
    try {
        session.set_itp_enabled(false);
    } catch (error) {
        printerr(error);
    }
    try {
        session.set_persistent_credential_storage_enabled(true);
    } catch (error) {
        printerr(error);
    }
    const cookies = session.get_cookie_manager();
    cookies.set_persistent_storage(
        GLib.build_filenamev([dataDir, 'cookies.sqlite']),
        WebKit.CookiePersistentStorage.SQLITE);
    try {
        cookies.set_accept_policy(WebKit.CookieAcceptPolicy.ALWAYS);
    } catch (error) {
        printerr(error);
    }

    const manager = new WebKit.UserContentManager();
    const webView = new WebKit.WebView({
        network_session: session,
        user_content_manager: manager,
    });
    try {
        webView.get_settings().set_user_agent(
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36');
    } catch (error) {
        printerr(error);
    }
    webView.connect('run-file-chooser', (_webView, request) => {
        try {
            if (imagePath)
                request.select_files([imagePath]);
            else
                request.cancel();
        } catch (error) {
            printerr(error);
            try {
                request.cancel();
            } catch (cancelError) {
                printerr(cancelError);
            }
        }
        return true;
    });
    webView.connect('load-changed', (_view, event) => {
        if (!WebKit.LoadEvent || event !== WebKit.LoadEvent.FINISHED)
            return;
        const uri = webView.get_uri() || '';
        if (uri.includes('gemini.google.com') && imagePath)
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 600, () => {
                drive(searchId);
                return GLib.SOURCE_REMOVE;
            });
    });
    webView._webkit = WebKit;
    return webView;
}

function submitImage(path) {
    imagePath = path;
    const id = ++searchId;
    reveal();
    if (!view)
        return;
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, 200, () => {
        drive(id);
        return GLib.SOURCE_REMOVE;
    });
}

function drive(id) {
    if (id !== searchId || !view || !imagePath)
        return;
    if (drive._id !== id) {
        drive._id = id;
        drive._started = Date.now();
    }
    if (Date.now() - drive._started > 45000)
        return;
    evalText(probeFor(id), status => {
        if (id !== searchId)
            return;
        const state = String(status || '').replace(/"/g, '').trim();
        if (state === 'sent' || state === 'away') {
            if (state === 'away')
                schedule(id, 500);
            return;
        }
        if (state === 'paste') {
            if (drive._pasted === id) {
                schedule(id, 400);
                return;
            }
            drive._pasted = id;
            putImageOnClipboard(imagePath);
            view.grab_focus();
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 250, () => {
                if (id !== searchId || !view)
                    return GLib.SOURCE_REMOVE;
                try {
                    view.grab_focus();
                    view.execute_editing_command('Paste');
                } catch (error) {
                    printerr(`Select to Search paste failed: ${error}`);
                }
                return GLib.SOURCE_REMOVE;
            });
        }
        schedule(id, 400);
    });
}

function schedule(id, delay) {
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, delay, () => {
        drive(id);
        return GLib.SOURCE_REMOVE;
    });
}

function putImageOnClipboard(path) {
    try {
        const file = Gio.File.new_for_path(path);
        const bytes = file.load_bytes(null)[0];
        const png = Gdk.ContentProvider.new_for_bytes('image/png', bytes);
        let provider = png;
        try {
            const texture = Gdk.Texture.new_from_filename(path);
            provider = Gdk.ContentProvider.new_union([
                png,
                Gdk.ContentProvider.new_for_value(texture),
            ]);
        } catch (error) {
            printerr(error);
        }
        Gdk.Display.get_default().get_clipboard().set_content(provider);
    } catch (error) {
        printerr(`Select to Search clipboard failed: ${error}`);
    }
}

function evaluate(script) {
    evalText(script, () => {});
}

function evalText(script, done) {
    if (!view) {
        done('');
        return;
    }
    try {
        view.evaluate_javascript(script, -1, null, null, null, (_view, result) => {
            let text = '';
            try {
                const value = view.evaluate_javascript_finish(result);
                if (value && typeof value.to_string === 'function')
                    text = value.to_string();
                else if (value != null)
                    text = String(value);
            } catch (error) {
                printerr(error);
            }
            done(text);
        });
    } catch (error) {
        printerr(error);
        done('');
    }
}

let cssProvider = null;
let themeSettings = null;
let styleManager = null;

function pinPath() {
    return GLib.build_filenamev([GLib.get_user_cache_dir(), 'circle-to-search', 'pin']);
}

function readPinned() {
    try {
        const [, bytes] = GLib.file_get_contents(pinPath());
        return new TextDecoder().decode(bytes).trim() === '1';
    } catch (error) {
        return false;
    }
}

function writePinned(active) {
    const path = pinPath();
    GLib.mkdir_with_parents(GLib.path_get_dirname(path), 0o700);
    GLib.file_set_contents(path, active ? '1' : '0');
}

function startAdw() {
    if (styleManager)
        return styleManager;
    try {
        imports.gi.versions.Adw = '1';
        const Adw = imports.gi.Adw;
        Adw.init();
        styleManager = Adw.StyleManager.get_default();
        styleManager.connect('notify::dark', () => installCss());
        return styleManager;
    } catch (error) {
        printerr(`Select to Search theme: ${error}`);
        return null;
    }
}

function watchTheme() {
    startAdw();
    if (themeSettings)
        return;
    try {
        themeSettings = new Gio.Settings({schema: 'org.gnome.desktop.interface'});
        themeSettings.connect('changed::color-scheme', () => installCss());
        themeSettings.connect('changed::gtk-theme', () => installCss());
    } catch (error) {
        printerr(error);
    }
}

function installCss() {
    const dark = shellDark();
    try {
        const gtk = Gtk.Settings.get_default();
        gtk.gtk_application_prefer_dark_theme = dark;
        gtk.gtk_theme_name = dark ? 'Adwaita-dark' : 'Adwaita';
    } catch (error) {
        printerr(error);
    }
    if (win) {
        win.remove_css_class('cts-dark');
        win.remove_css_class('cts-light');
        win.add_css_class(dark ? 'cts-dark' : 'cts-light');
    }
    const display = Gdk.Display.get_default();
    if (cssProvider)
        Gtk.StyleContext.remove_provider_for_display(display, cssProvider);
    cssProvider = new Gtk.CssProvider();
    cssProvider.load_from_string(dark ? CSS_DARK : CSS_LIGHT);
    Gtk.StyleContext.add_provider_for_display(
        display,
        cssProvider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION);
    applyWebKitTheme(dark);
}

function applyWebKitTheme(dark) {
    if (!view)
        return;
    try {
        const settings = view.get_settings();
        const WebKit = view._webkit || {};
        const scheme = dark
            ? (WebKit.PreferredColorScheme?.DARK ?? WebKit.ColorScheme?.DARK ?? 2)
            : (WebKit.PreferredColorScheme?.LIGHT ?? WebKit.ColorScheme?.LIGHT ?? 1);
        const attempts = [
            () => settings.set_preferred_color_scheme(scheme),
            () => {
                settings.preferred_color_scheme = scheme;
            },
            () => settings.set_color_scheme(scheme),
            () => {
                settings.color_scheme = scheme;
            },
        ];
        for (const attempt of attempts) {
            try {
                attempt();
            } catch (error) {
                // This WebKit build uses a different property name.
            }
        }
        const rgba = new Gdk.RGBA();
        rgba.parse(dark ? '#1e1e1e' : '#ffffff');
        view.set_background_color(rgba);
    } catch (error) {
        printerr(error);
    }
}

function shellDark() {
    try {
        const manager = startAdw();
        if (manager)
            return Boolean(manager.get_dark());
    } catch (error) {
        printerr(error);
    }
    try {
        const iface = themeSettings || new Gio.Settings({
            schema: 'org.gnome.desktop.interface',
        });
        const scheme = iface.get_string('color-scheme');
        if (scheme === 'prefer-dark')
            return true;
        if (scheme === 'prefer-light')
            return false;
        const theme = iface.get_string('gtk-theme') || '';
        if (theme.toLowerCase().includes('dark'))
            return true;
    } catch (error) {
        printerr(error);
    }
    return false;
}

const CSS_LIGHT = `
window.cts-sheet { background-color: transparent; }
.cts-menu {
  background-color: rgba(255, 255, 255, 0.72);
  color: #1e1e1e;
  border-radius: 18px;
  border: 1px solid rgba(0, 0, 0, 0.12);
  padding: 8px;
}
.cts-clip { border-radius: 12px; background-color: #ffffff; }
.cts-name { font-size: 13px; font-weight: 700; }
button.cts-close {
  min-width: 28px;
  min-height: 28px;
  padding: 0;
  margin: 0 0 2px;
  border-radius: 999px;
  background: transparent;
  color: #5e5c64;
}
button.cts-close:hover { background: rgba(0, 0, 0, 0.06); }
button.cts-pin:checked { background: rgba(28, 113, 216, 0.2); color: #1c71d8; }
`;

const CSS_DARK = `
window.cts-sheet { background-color: transparent; }
.cts-menu {
  background-color: rgba(36, 36, 36, 0.68);
  color: #ffffff;
  border-radius: 18px;
  border: 1px solid rgba(255, 255, 255, 0.08);
  padding: 8px;
}
.cts-clip { border-radius: 12px; background-color: #1e1e1e; }
.cts-name { font-size: 13px; font-weight: 700; }
button.cts-close {
  min-width: 28px;
  min-height: 28px;
  padding: 0;
  margin: 0 0 2px;
  border-radius: 999px;
  background: transparent;
  color: #deddda;
}
button.cts-close:hover { background: rgba(255, 255, 255, 0.08); }
button.cts-pin:checked { background: rgba(138, 180, 248, 0.22); color: #8ab4f8; }
`;

function probeFor(id) {
    return PROBE.replace("__SEARCH_ID__", String(id));
}

const PROBE = `
(() => {
    const searchId = __SEARCH_ID__;
    function walk(fn) {
        const stack = [document];
        const seen = new Set();
        while (stack.length) {
            const node = stack.pop();
            if (!node || seen.has(node))
                continue;
            seen.add(node);
            fn(node);
            let all = [];
            try {
                all = node.querySelectorAll ? node.querySelectorAll("*") : [];
            } catch (error) {}
            for (const el of all) {
                if (el.shadowRoot)
                    stack.push(el.shadowRoot);
            }
        }
    }
    function deepQuery(selector) {
        let found = null;
        walk(node => {
            if (found || !node.querySelector)
                return;
            try {
                found = node.querySelector(selector);
            } catch (error) {}
        });
        return found;
    }
    function deepAll(selector) {
        const out = [];
        walk(node => {
            if (!node.querySelectorAll)
                return;
            try {
                node.querySelectorAll(selector).forEach(el => out.push(el));
            } catch (error) {}
        });
        return out;
    }
    function chipButtons() {
        return deepAll("button").filter(item => /remove (file|image|attachment)/i.test(item.getAttribute("aria-label") || ""));
    }
    if (!(location.hostname || "").endsWith("gemini.google.com"))
        return "away";
    if (window.__ctsSent === searchId)
        return "sent";
    if (window.__ctsActive !== searchId) {
        window.__ctsActive = searchId;
        window.__ctsPasted = false;
        window.__ctsRetried = false;
        window.__ctsReadyAt = 0;
        window.__ctsPasteAt = 0;
        window.__ctsPrompted = false;
        window.__ctsBegan = Date.now();
        if (!window.__ctsBoot)
            window.__ctsBoot = Date.now();
        const leftover = chipButtons()[0];
        if (leftover) {
            leftover.click();
            return "clear";
        }
    }
    function queryIn(root, selector) {
        let found = null;
        const stack = [root];
        const seen = new Set();
        while (stack.length) {
            const node = stack.pop();
            if (!node || seen.has(node))
                continue;
            seen.add(node);
            try {
                if (!found && node.querySelector)
                    found = node.querySelector(selector);
            } catch (error) {}
            if (found)
                return found;
            let all = [];
            try {
                all = node.querySelectorAll ? node.querySelectorAll("*") : [];
            } catch (error) {}
            for (const el of all) {
                if (el.shadowRoot)
                    stack.push(el.shadowRoot);
            }
        }
        return null;
    }
    const rich = deepQuery("rich-textarea");
    let box = rich ? (queryIn(rich, '[contenteditable="true"]') || queryIn(rich, "textarea")) : null;
    if (!box && Date.now() - (window.__ctsBegan || Date.now()) > 5000)
        box = deepQuery('[contenteditable="true"]') || deepQuery("textarea") || deepQuery("div.ql-editor");
    if (!box)
        return "wait";
    box.focus();
    const host = deepQuery("rich-textarea") || box.parentElement || box;
    function countImages(root) {
        let count = 0;
        const roots = [root];
        if (root && root.shadowRoot)
            roots.push(root.shadowRoot);
        for (const node of roots) {
            if (!node || !node.querySelectorAll)
                continue;
            node.querySelectorAll("img").forEach(img => {
                const src = img.getAttribute("src") || "";
                if (src.startsWith("blob:") || src.startsWith("data:"))
                    count += 1;
            });
        }
        return count;
    }
    if (window.__ctsMark !== searchId) {
        window.__ctsMark = searchId;
        window.__ctsBase = countImages(host);
        window.__ctsChips = chipButtons().length;
    }
    const attached = countImages(host) > window.__ctsBase || chipButtons().length > window.__ctsChips;
    const button = deepAll('button, [role="button"]').find(item => {
        const icon = item.querySelector?.("mat-icon, .google-symbols, .mat-icon");
        const label = (
            (item.getAttribute("aria-label") || "") + " " +
            (item.getAttribute("data-mat-icon-name") || "") + " " +
            (icon?.getAttribute?.("data-mat-icon-name") || "") + " " +
            (icon?.getAttribute?.("fonticon") || "") + " " +
            (icon?.textContent || "") + " " +
            (item.className || "") + " " +
            (item.innerText || "")
        ).toLowerCase();
        if (label.includes("feedback") || label.includes("stop"))
            return false;
        return label.includes("send");
    });
    const sendReady = button && !button.disabled && button.getAttribute("aria-disabled") !== "true";
    function boxReady(node) {
        const rect = node.getBoundingClientRect();
        return rect.width > 8 && rect.height > 8;
    }
    if (!window.__ctsPasted) {
        if (!boxReady(box))
            return "wait";
        if (!window.__ctsReadyAt)
            window.__ctsReadyAt = Date.now();
        const cold = Date.now() - (window.__ctsBoot || Date.now()) < 25000;
        if (Date.now() - window.__ctsReadyAt < (cold ? 2200 : 700))
            return "wait";
        window.__ctsPasted = true;
        window.__ctsPasteAt = Date.now();
        box.focus();
        return "paste";
    }
    if (sendReady && window.__ctsPasteAt && Date.now() - window.__ctsPasteAt > 900) {
        button.click();
        window.__ctsSent = searchId;
        return "sent";
    }
    if (!window.__ctsPrompted && window.__ctsPasteAt && Date.now() - window.__ctsPasteAt > 2000 && !sendReady) {
        window.__ctsPrompted = true;
        box.focus();
        document.execCommand("insertText", false, "What is this?");
    }
    return "wait";
})()
`;

const invocation = [imports.system.programInvocationName || 'gemini-window'];
if (ARGV[0])
    invocation.push(ARGV[0]);
app.run(invocation);
