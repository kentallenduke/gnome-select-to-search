// SPDX-License-Identifier: GPL-2.0-or-later

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import St from 'gi://St';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import {ScreenshotUI} from 'resource:///org/gnome/shell/ui/screenshot.js';

import {CircleSession} from './circle.js';

export default class CircleToSearchExtension extends Extension {
    enable() {
        this._destroyed = false;
        this._arm = false;
        this._shortcutBound = false;
        this._settings = this.getSettings();
        this._session = new CircleSession(this._settings, this.dir.get_path());

        this._originalOpen = ScreenshotUI.prototype.open;
        const ext = this;
        ScreenshotUI.prototype.open = function (mode) {
            const direct = ext._arm;
            if (direct) {
                try {
                    ext._session.attach(this);
                    ext._session.concealChrome();
                } catch (error) {
                    logError(error, 'Select to Search');
                }
            }
            const result = ext._originalOpen.call(this, mode);
            try {
                ext._session.attach(this);
                if (direct) {
                    ext._arm = false;
                    ext._session.concealChrome();
                    ext._session.activate();
                }
            } catch (error) {
                logError(error, 'Select to Search');
            }
            return result;
        };

        this._installModeKey();
        this._bindShortcut();
        this._syncPanel();
        this._settingsIds = [
            this._settings.connect('changed::circle-to-search', () => {
                this._bindShortcut();
            }),
            this._settings.connect('changed::show-top-bar', () => {
                this._syncPanel();
            }),
            this._settings.connect('changed::shake-sensitivity', () => {
                this._shakeSensitivity = this._settings.get_int('shake-sensitivity');
            }),
            this._settings.connect('changed::shake-enabled', () => {
                this._syncShake();
            }),
        ];
        this._syncShake();

        GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
            if (!this._destroyed && Main.screenshotUI)
                this._session.attach(Main.screenshotUI);
            return GLib.SOURCE_REMOVE;
        });
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1200, () => {
            if (!this._destroyed)
                this._session.preload();
            return GLib.SOURCE_REMOVE;
        });
    }

    disable() {
        this._destroyed = true;
        this._arm = false;
        if (this._settingsIds) {
            for (const id of this._settingsIds)
                this._settings.disconnect(id);
            this._settingsIds = null;
        }
        this._stopShake();
        this._dismissGlow();
        this._unbindShortcut();
        this._removeModeKey();
        this._removePanel();
        if (ScreenshotUI.prototype.open !== this._originalOpen)
            ScreenshotUI.prototype.open = this._originalOpen;
        this._session.destroy();
        this._session = null;
        this._settings = null;
    }

    _syncPanel() {
        if (this._settings.get_boolean('show-top-bar'))
            this._addPanelButton();
        else
            this._removePanel();
    }

    _removePanel() {
        const existing = Main.panel.statusArea?.['circle-to-search'];
        if (existing) {
            try {
                existing.destroy();
            } catch (error) {
                logError(error, 'Select to Search');
            }
        }
        this._panelButton = null;
    }

    _addPanelButton() {
        this._removePanel();

        const button = new PanelMenu.Button(0.0, 'Select to Search', true);
        const icon = new St.DrawingArea({
            width: 16,
            height: 16,
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.CENTER,
            reactive: false,
        });
        icon.connect('repaint', () => this._paintPanelIcon(icon));
        button.add_child(icon);
        this._armPanelClick(button);
        Main.panel.addToStatusArea('circle-to-search', button, 1, 'right');
        this._panelButton = button;
        icon.queue_repaint();
    }

    _armPanelClick(button) {
        const Gesture = Clutter.ClickGesture;
        if (typeof Gesture === 'function') {
            const click = new Gesture();
            click.connect('recognize', () => this._trigger());
            button.add_action(click);
            return;
        }
        button.connect('event', (_actor, event) => {
            if (event.type() !== Clutter.EventType.BUTTON_RELEASE)
                return Clutter.EVENT_PROPAGATE;
            this._trigger();
            return Clutter.EVENT_STOP;
        });
    }

    _paintPanelIcon(area) {
        const cr = area.get_context();
        if (!cr)
            return;
        try {
            let red = 1;
            let green = 1;
            let blue = 1;
            let alpha = 0.92;
            try {
                const color = area.get_theme_node().get_foreground_color();
                red = color.red / 255;
                green = color.green / 255;
                blue = color.blue / 255;
                alpha = Math.max(0.75, color.alpha / 255);
            } catch (error) {
                logError(error, 'Select to Search');
            }
            cr.setSourceRGBA(red, green, blue, alpha);
            cr.moveTo(2.1, 1.1);
            cr.lineTo(2.1, 12.4);
            cr.lineTo(5.1, 9.5);
            cr.lineTo(7.3, 13.7);
            cr.lineTo(8.9, 12.9);
            cr.lineTo(6.7, 8.7);
            cr.lineTo(10.5, 8.5);
            cr.closePath();
            cr.fill();
            cr.moveTo(12.4, 1.0);
            cr.lineTo(13.0, 2.8);
            cr.lineTo(14.8, 3.4);
            cr.lineTo(13.0, 4.0);
            cr.lineTo(12.4, 5.8);
            cr.lineTo(11.8, 4.0);
            cr.lineTo(10.0, 3.4);
            cr.lineTo(11.8, 2.8);
            cr.closePath();
            cr.fill();
        } finally {
            cr.$dispose();
        }
    }

    _syncShake() {
        if (this._settings.get_boolean('shake-enabled'))
            this._startShake();
        else
            this._stopShake();
    }

    _startShake() {
        if (this._shakeId)
            return;
        this._shakeSensitivity = this._settings.get_int('shake-sensitivity');
        this._clearShake();
        this._shakeAt = 0;
        this._shakeId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 20, () => {
            if (!this._destroyed)
                this._sampleShake();
            return this._destroyed ? GLib.SOURCE_REMOVE : GLib.SOURCE_CONTINUE;
        });
    }

    _stopShake() {
        if (this._shakeId) {
            GLib.source_remove(this._shakeId);
            this._shakeId = 0;
        }
    }

    _clearShake() {
        this._shakeLast = null;
        this._legX = 0;
        this._legY = 0;
        this._dirX = 0;
        this._dirY = 0;
        this._turns = [];
    }

    _readPointer() {
        try {
            const tracker = Meta.CursorTracker.get_for_display(global.display);
            const result = tracker.get_pointer();
            if (result && typeof result.x === 'number')
                return {x: result.x, y: result.y};
            if (result && result[0] && typeof result[0].x === 'number')
                return {x: result[0].x, y: result[0].y, mods: result[1] || 0};
            if (result && result.length >= 2 && typeof result[0] === 'number')
                return {x: result[0], y: result[1], mods: result[2] || 0};
        } catch (error) {
            if (!this._pointerError) {
                this._pointerError = true;
                logError(error, 'Select to Search');
            }
        }
        try {
            const pointer = global.get_pointer();
            if (pointer && pointer.length >= 2)
                return {x: pointer[0], y: pointer[1], mods: pointer[2] || 0};
        } catch (error) {
            if (!this._pointerError) {
                this._pointerError = true;
                logError(error, 'Select to Search');
            }
        }
        return null;
    }

    _sampleShake() {
        try {
            const point = this._readPointer();
            if (!point)
                return;
            const now = Date.now();
            const buttons = (Clutter.ModifierType.BUTTON1_MASK || 256) |
                (Clutter.ModifierType.BUTTON2_MASK || 512) |
                (Clutter.ModifierType.BUTTON3_MASK || 1024);
            if (Main.screenshotUI?.visible || (point.mods & buttons)) {
                this._clearShake();
                return;
            }
            if (now - this._shakeAt < 1500)
                return;
            const last = this._shakeLast;
            this._shakeLast = {x: point.x, y: point.y, t: now};
            if (!last)
                return;
            if (now - last.t > 120) {
                this._clearShake();
                this._shakeLast = {x: point.x, y: point.y, t: now};
                return;
            }
            const dx = point.x - last.x;
            const dy = point.y - last.y;
            if (Math.hypot(dx, dy) < 2)
                return;
            const sensitivity = Math.min(100, Math.max(1, this._shakeSensitivity || 50));
            const ease = (sensitivity - 1) / 99;
            const minSwing = 190 - ease * 120;
            const x = this._pushAxis(dx, this._legX, this._dirX, minSwing, now);
            const y = this._pushAxis(dy, this._legY, this._dirY, minSwing, now);
            this._legX = x.leg;
            this._dirX = x.dir;
            this._legY = y.leg;
            this._dirY = y.dir;
            const windowMs = 560 + ease * 220;
            this._turns = this._turns.filter(time => now - time <= windowMs);
            const needed = ease > 0.8 ? 3 : 4;
            if (this._turns.length >= needed) {
                this._clearShake();
                this._shakeAt = now;
                this._flashShake(point.x, point.y);
                GLib.timeout_add(GLib.PRIORITY_DEFAULT, 160, () => {
                    if (!this._destroyed)
                        this._trigger();
                    return GLib.SOURCE_REMOVE;
                });
            }
        } catch (error) {
            logError(error, 'Select to Search');
        }
    }

    _pushAxis(delta, leg, dir, minSwing, now) {
        if (Math.abs(delta) < 1)
            return {leg, dir};
        const next = delta > 0 ? 1 : -1;
        if (dir && next !== dir) {
            if (Math.abs(delta) < 12 && Math.abs(leg) > 24)
                return {leg, dir};
            if (Math.abs(leg) >= minSwing)
                this._turns.push(now);
            return {leg: delta, dir: next};
        }
        return {leg: leg + delta, dir: next};
    }

    _flashShake(x, y) {
        this._dismissGlow();
        const size = 240;
        const area = new St.DrawingArea({
            width: size,
            height: size,
            reactive: false,
            x: Math.round(x - size / 2),
            y: Math.round(y - size / 2),
        });
        const started = Date.now();
        area.connect('repaint', () => {
            const cr = area.get_context();
            if (!cr)
                return;
            try {
                const t = Math.min(1, (Date.now() - started) / 620);
                const fade = Math.pow(1 - t, 1.4);
                const radius = 16 + t * 92;
                const colors = [
                    [0.259, 0.522, 0.957],
                    [0.918, 0.263, 0.208],
                    [0.984, 0.737, 0.020],
                    [0.204, 0.659, 0.325],
                ];
                const cx = size / 2;
                const cy = size / 2;
                colors.forEach((color, index) => {
                    cr.setSourceRGBA(color[0], color[1], color[2], fade * (0.42 - index * 0.07));
                    cr.setLineWidth(14 - index * 2);
                    cr.arc(cx, cy, Math.max(4, radius - index * 8), 0, Math.PI * 2);
                    cr.stroke();
                });
                cr.setSourceRGBA(1, 1, 1, fade * 0.9);
                cr.setLineWidth(2.5);
                cr.arc(cx, cy, Math.max(3, radius * 0.42), 0, Math.PI * 2);
                cr.stroke();
            } finally {
                cr.$dispose();
            }
        });
        Main.uiGroup.add_child(area);
        Main.uiGroup.set_child_above_sibling(area, null);
        this._glow = area;
        this._glowId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 16, () => {
            if (!this._glow) {
                this._glowId = 0;
                return GLib.SOURCE_REMOVE;
            }
            this._glow.queue_repaint();
            if (Date.now() - started > 640) {
                const glow = this._glow;
                this._glow = null;
                this._glowId = 0;
                glow?.destroy();
                return GLib.SOURCE_REMOVE;
            }
            return GLib.SOURCE_CONTINUE;
        });
    }

    _dismissGlow() {
        if (this._glowId) {
            GLib.source_remove(this._glowId);
            this._glowId = 0;
        }
        if (this._glow) {
            this._glow.destroy();
            this._glow = null;
        }
    }

    _trigger() {
        const ui = Main.screenshotUI;
        if (!ui || this._destroyed)
            return;
        try {
            this._session.attach(ui);
        } catch (error) {
            logError(error, 'Select to Search');
            return;
        }
        if (ui.visible) {
            this._session.activate();
            return;
        }
        this._arm = true;
        ui.open().catch(error => logError(error, 'Select to Search'));
    }

    _bindShortcut() {
        this._unbindShortcut();
        const modes = Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW;
        Main.wm.addKeybinding(
            'circle-to-search',
            this._settings,
            Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
            modes,
            () => this._trigger());
        this._shortcutBound = true;
    }

    _unbindShortcut() {
        if (!this._shortcutBound)
            return;
        Main.wm.removeKeybinding('circle-to-search');
        this._shortcutBound = false;
    }

    /// L, while the screenshot tool is open. C is already Screen.
    _installModeKey() {
        try {
            ScreenshotUI.get_binding_pool().install_closure(
                'circle-to-search-mode',
                Clutter.KEY_l,
                0,
                obj => {
                    if (this._destroyed)
                        return Clutter.EVENT_PROPAGATE;
                    this._session.attach(obj);
                    this._session.activate();
                    return Clutter.EVENT_STOP;
                });
            this._modeKey = true;
        } catch (error) {
            logError(error, 'Select to Search mode key');
        }
    }

    _removeModeKey() {
        if (!this._modeKey)
            return;
        try {
            const pool = ScreenshotUI.get_binding_pool();
            if (pool.remove_action)
                pool.remove_action('circle-to-search-mode');
            else
                pool.install_closure(
                    'circle-to-search-mode',
                    Clutter.KEY_l,
                    0,
                    () => Clutter.EVENT_PROPAGATE);
        } catch (error) {
            logError(error, 'Select to Search mode key');
        }
        this._modeKey = false;
    }
}
