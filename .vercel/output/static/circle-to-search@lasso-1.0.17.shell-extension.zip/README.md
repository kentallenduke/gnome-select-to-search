# Circle to Search

A GNOME 51 extension that adds a circle gesture to the native screenshot tool.

Draw on the frozen screenshot, then release. A Gemini window opens at the bottom right, pastes that image once, and sends it. Sign in the first time. The helper keeps that login.

This is not a Google product.

## Install

Requirements: GNOME Shell 51, and WebKitGTK 6 (already part of the GNOME desktop). Do not unzip the file.

```bash
cd ~/Downloads
gnome-extensions install --force circle-to-search@lasso-1.0.17.shell-extension.zip
gnome-extensions enable circle-to-search@lasso
```

Then log out and back in. Shell keeps the previous extension in memory until a new login. Do this again after every update. `Alt+F2`, `r` does not reload it on Wayland.

## Use it

| Action | What happens |
| --- | --- |
| Top bar icon | Opens Circle mode. The icon is the monochrome pointer. |
| Super+Print | Opens the screenshot tool already in Circle mode. Change this in the extension settings. |
| Print, then Circle | The Circle button sits next to Selection, Screen, and Window. |
| L | While the screenshot tool is open, switches to Circle. (C is already Screen.) |
| Draw and release | Crops the ink and opens Gemini, which pastes and sends. |

Escape still closes the screenshot tool.

## License

GPL-2.0-or-later. It runs inside GNOME Shell, which is GPL.
