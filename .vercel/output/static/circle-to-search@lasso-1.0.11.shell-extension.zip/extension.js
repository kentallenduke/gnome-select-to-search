// SPDX-License-Identifier: GPL-2.0-or-later

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {ScreenshotUI} from 'resource:///org/gnome/shell/ui/screenshot.js';

import {CircleSession} from './circle.js';

export default class CircleToSearchExtension extends Extension {
    enable() {
        this._destroyed = false;
        this._arm = false;
        this._shortcutBound = false;
        this._settings = this.getSettings();
        this._session = new CircleSession(this._settings, this.dir.get_path());

        this._originalOpen = ScreenshotUI.prototype.open;
        const ext = this;
        ScreenshotUI.prototype.open = function (mode) {
            const result = ext._originalOpen.call(this, mode);
            try {
                ext._session.attach(this);
                if (ext._arm) {
                    ext._arm = false;
                    Promise.resolve(result).then(() => {
                        if (!ext._destroyed)
                            ext._session.activate();
                    }).catch(error => logError(error, 'Circle to Search'));
                }
            } catch (error) {
                logError(error, 'Circle to Search');
            }
            return result;
        };

        this._installModeKey();
        this._bindShortcut();
        this._settingsId = this._settings.connect('changed::circle-to-search', () => {
            this._bindShortcut();
        });

        GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
            if (!this._destroyed && Main.screenshotUI)
                this._session.attach(Main.screenshotUI);
            return GLib.SOURCE_REMOVE;
        });
    }

    disable() {
        this._destroyed = true;
        this._arm = false;
        if (this._settingsId) {
            this._settings.disconnect(this._settingsId);
            this._settingsId = 0;
        }
        this._unbindShortcut();
        this._removeModeKey();
        if (ScreenshotUI.prototype.open !== this._originalOpen)
            ScreenshotUI.prototype.open = this._originalOpen;
        this._session.destroy();
        this._session = null;
        this._settings = null;
    }

    _trigger() {
        const ui = Main.screenshotUI;
        if (!ui || this._destroyed)
            return;
        try {
            this._session.attach(ui);
        } catch (error) {
            logError(error, 'Circle to Search');
            return;
        }
        if (ui.visible) {
            this._session.activate();
            return;
        }
        this._arm = true;
        ui.open().catch(error => logError(error, 'Circle to Search'));
    }

    _bindShortcut() {
        this._unbindShortcut();
        const modes = Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW;
        Main.wm.addKeybinding(
            'circle-to-search',
            this._settings,
            Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
            modes,
            () => this._trigger());
        this._shortcutBound = true;
    }

    _unbindShortcut() {
        if (!this._shortcutBound)
            return;
        Main.wm.removeKeybinding('circle-to-search');
        this._shortcutBound = false;
    }

    /// L, while the screenshot tool is open. C is already Screen.
    _installModeKey() {
        try {
            ScreenshotUI.get_binding_pool().install_closure(
                'circle-to-search-mode',
                Clutter.KEY_l,
                0,
                obj => {
                    if (this._destroyed)
                        return Clutter.EVENT_PROPAGATE;
                    this._session.attach(obj);
                    this._session.activate();
                    return Clutter.EVENT_STOP;
                });
            this._modeKey = true;
        } catch (error) {
            logError(error, 'Circle to Search mode key');
        }
    }

    _removeModeKey() {
        if (!this._modeKey)
            return;
        try {
            const pool = ScreenshotUI.get_binding_pool();
            if (pool.remove_action)
                pool.remove_action('circle-to-search-mode');
            else
                pool.install_closure(
                    'circle-to-search-mode',
                    Clutter.KEY_l,
                    0,
                    () => Clutter.EVENT_PROPAGATE);
        } catch (error) {
            logError(error, 'Circle to Search mode key');
        }
        this._modeKey = false;
    }
}
