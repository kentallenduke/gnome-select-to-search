# Circle to Search

A GNOME 51 extension that adds a circle gesture to the **native screenshot tool**.

The phone gesture, on the desktop you already have: the screen freezes in GNOME’s screenshot UI, you draw on that frozen frame, and the region is cropped with the same `Shell.Screenshot.composite_to_stream` call the shutter uses. Text is read on this computer with Tesseract. A search engine or Google Lens opens only when you ask.

This is not a Google product and it does not upload the image on its own.

## Install

Requirements: GNOME Shell 51. Optional: the `tesseract-ocr` package (and a language pack, such as `tesseract-ocr-eng` or `tesseract-ocr-jpn`).

```bash
gnome-extensions install --force circle-to-search@lasso.shell-extension.zip
gnome-extensions enable circle-to-search@lasso
```

If the shortcut does not respond, turn the extension off and on again. Wayland will not reload the shell with `Alt+F2`, `r`.

## Use it

| Action | What happens |
| --- | --- |
| Super+Print | Opens the screenshot tool already in Circle mode. Change this in the extension settings. |
| Print, then Circle | The Circle button sits next to Selection, Screen, and Window. |
| L | While the screenshot tool is open, switches to Circle. (C is already Screen.) |
| Draw and release | Searches the ink, plus a little padding. A tap searches the area under the pointer. |
| Enter, Space, or the shutter | Searches the current ink. Those keys already belong to the screenshot tool. |
| Escape | Closes the screenshot tool, as it always has. |

The result sheet can search the web, translate, copy the text, or open Lens. Lens needs a paste: the crop is on the clipboard (Ctrl+V).

## What it touches

- Inserts one toggle into `ScreenshotUI`’s type row and an ink layer above the area selector.
- While Circle is on, Selection / Screen / Window are unchecked, so the rectangle handles get out of the way.
- Crops `ScreenshotUI._stageScreenshot` — the frozen frame — not a second live capture, so the picture matches what you circled.
- Leaves the shutter, screen recording, and the other three tools alone when Circle is off.

## Preferences

Search engine (Google, DuckDuckGo, Brave, Startpage), Tesseract language code, clipboard copy, optional save under `Pictures/Screenshots`, stroke padding, and the shortcut.

## License

GPL-2.0-or-later. It runs inside GNOME Shell, which is GPL.
