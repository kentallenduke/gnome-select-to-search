// SPDX-License-Identifier: GPL-2.0-or-later

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk?version=4.0';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {SHORTCUTS} from './engines.js';

export default class CircleToSearchPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        const page = new Adw.PreferencesPage({
            title: 'Circle to Search',
            icon_name: 'edit-find-symbolic',
        });
        window.add(page);

        const gesture = new Adw.PreferencesGroup({
            title: 'Gesture',
            description: 'Super+Print opens the screenshot tool in circle mode. Draw, then release. Gemini opens in its own window.',
        });
        page.add(gesture);

        const shortcuts = new Gtk.StringList();
        for (const [, label] of SHORTCUTS)
            shortcuts.append(label);
        const currentAccel = settings.get_strv('circle-to-search')[0] ?? '';
        let shortcutIndex = SHORTCUTS.findIndex(([accel]) => accel === currentAccel);
        if (shortcutIndex < 0)
            shortcutIndex = 0;
        const shortcutRow = new Adw.ComboRow({
            title: 'Shortcut',
            subtitle: 'Opens circle mode directly',
            model: shortcuts,
            selected: shortcutIndex,
        });
        shortcutRow.connect('notify::selected', () => {
            const accel = SHORTCUTS[shortcutRow.selected]?.[0];
            if (accel)
                settings.set_strv('circle-to-search', [accel]);
        });
        gesture.add(shortcutRow);

        const padding = new Gtk.Adjustment({
            lower: 0,
            upper: 160,
            step_increment: 4,
            page_increment: 20,
            value: settings.get_int('stroke-padding'),
        });
        const paddingRow = new Adw.SpinRow({
            title: 'Padding',
            subtitle: 'Extra pixels kept around the ink',
            adjustment: padding,
        });
        padding.connect('value-changed', () => {
            settings.set_int('stroke-padding', Math.round(padding.value));
        });
        gesture.add(paddingRow);

        const search = new Adw.PreferencesGroup({
            title: 'Gemini',
            description: 'Releasing the stroke closes the screenshot and opens Gemini. The circled image is copied so you can paste it.',
        });
        page.add(search);

        const copyImage = new Adw.SwitchRow({
            title: 'Copy the image',
            subtitle: 'Put the crop on the clipboard as a PNG',
        });
        settings.bind('copy-image', copyImage, 'active', Gio.SettingsBindFlags.DEFAULT);
        search.add(copyImage);

        const saveFile = new Adw.SwitchRow({
            title: 'Save a PNG',
            subtitle: 'Also write Pictures/Screenshots',
        });
        settings.bind('save-file', saveFile, 'active', Gio.SettingsBindFlags.DEFAULT);
        search.add(saveFile);
    }
}
