// SPDX-License-Identifier: GPL-2.0-or-later

export const SHORTCUTS = [
    ['<Super>Print', 'Super + Print Screen'],
    ['<Control>Print', 'Ctrl + Print Screen'],
    ['<Super><Shift>c', 'Super + Shift + C'],
    ['<Control><Shift>s', 'Ctrl + Shift + S'],
];

export const LENS_URL = 'https://lens.google.com/';

export function searchUrl(text) {
    const q = encodeURIComponent((text || '').slice(0, 1800));
    return `https://gemini.google.com/app?q=${q}`;
}

export function translateUrl(text) {
    const q = encodeURIComponent(text.slice(0, 1800));
    return `https://translate.google.com/?sl=auto&tl=en&op=translate&text=${q}`;
}