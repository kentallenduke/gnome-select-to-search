// SPDX-License-Identifier: GPL-2.0-or-later

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class CircleToSearchPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const page = new Adw.PreferencesPage({
            title: 'Select to Search',
            icon_name: 'edit-find-symbolic',
        });
        window.add(page);

        const group = new Adw.PreferencesGroup();
        page.add(group);

        const topBar = new Adw.SwitchRow({
            title: 'Show in the top bar',
            subtitle: 'Adds a Select to Search button next to the other status icons',
        });
        this.getSettings().bind(
            'show-top-bar',
            topBar,
            'active',
            Gio.SettingsBindFlags.DEFAULT);
        group.add(topBar);

        const shake = new Adw.ActionRow({
            title: 'Shake sensitivity',
            subtitle: 'Shake the pointer to open Select to Search. Higher triggers more easily',
        });
        const scale = new Gtk.Scale({
            orientation: Gtk.Orientation.HORIZONTAL,
            draw_value: true,
            digits: 0,
            hexpand: true,
            width_request: 180,
            valign: Gtk.Align.CENTER,
            adjustment: new Gtk.Adjustment({
                lower: 1,
                upper: 100,
                step_increment: 1,
                page_increment: 10,
            }),
        });
        this.getSettings().bind(
            'shake-sensitivity',
            scale.get_adjustment(),
            'value',
            Gio.SettingsBindFlags.DEFAULT);
        shake.add_suffix(scale);
        group.add(shake);
    }
}
