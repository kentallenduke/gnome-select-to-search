#!/usr/bin/env gjs
// Resident helper. One process, one saved login, a bottom sheet.

imports.gi.versions.Gtk = '4.0';
imports.gi.versions.Gdk = '4.0';

const {GLib, Gio, Gtk, Gdk} = imports.gi;

const GEMINI = 'https://gemini.google.com/app';

GLib.set_prgname('circle-to-search-gemini');

const app = new Gtk.Application({
    application_id: 'org.gnome.circle_to_search.GeminiPanel',
    flags: Gio.ApplicationFlags.HANDLES_COMMAND_LINE,
});

let win = null;
let view = null;
let imagePath = '';
let searchId = 0;

app.connect('startup', () => app.hold());

app.connect('command-line', (application, commandLine) => {
    const next = imageArg(commandLine.get_arguments());
    try {
        if (!win)
            build(application);
        if (next)
            submitImage(next);
        else
            reveal();
    } catch (error) {
        printerr(error);
        if (win)
            showError(String(error));
    }
    return 0;
});

function imageArg(args) {
    for (let i = args.length - 1; i >= 0; i--) {
        const arg = args[i] || '';
        if (arg.endsWith('.png'))
            return arg;
    }
    return '';
}

function build(application) {
    win = new Gtk.ApplicationWindow({
        application,
        title: 'Gemini',
        decorated: false,
        resizable: true,
    });
    win.add_css_class('cts-sheet');
    installCss();
    anchorTopRight(win);

    const root = new Gtk.Box({
        orientation: Gtk.Orientation.VERTICAL,
        spacing: 0,
    });
    const head = new Gtk.Box({
        orientation: Gtk.Orientation.HORIZONTAL,
        spacing: 8,
    });
    head.add_css_class('cts-head');
    const title = new Gtk.Label({label: 'Gemini', xalign: 0, hexpand: true});
    title.add_css_class('cts-title');
    const close = new Gtk.Button({icon_name: 'window-close-symbolic'});
    close.add_css_class('cts-close');
    close.add_css_class('flat');
    close.connect('clicked', () => win.hide());
    head.append(title);
    head.append(close);
    root.append(head);
    win._root = root;
    win.set_child(root);
    win.connect('close-request', () => {
        win.hide();
        return true;
    });

    try {
        view = makeView();
        view.set_vexpand(true);
        view.set_hexpand(true);
        root.append(view);
        view.load_uri(GEMINI);
    } catch (error) {
        printerr(error);
        showError(String(error));
    }
    reveal();
}

function showError(message) {
    const label = new Gtk.Label({
        label: message,
        wrap: true,
        margin_top: 12,
        margin_bottom: 16,
        margin_start: 16,
        margin_end: 16,
    });
    label.set_vexpand(true);
    win._root.append(label);
}

function reveal() {
    const geo = monitorGeometry();
    win.set_default_size(460, Math.max(560, geo.height - 64));
    win.present();
}

function monitorGeometry() {
    try {
        const monitors = Gdk.Display.get_default().get_monitors();
        let best = null;
        let area = 0;
        for (let i = 0; i < monitors.get_n_items(); i++) {
            const geo = monitors.get_item(i).get_geometry();
            if (geo.width * geo.height > area) {
                best = geo;
                area = geo.width * geo.height;
            }
        }
        if (best)
            return best;
    } catch (error) {
        printerr(error);
    }
    return {width: 1280, height: 800};
}

function anchorTopRight(window) {
    try {
        imports.gi.versions.Gtk4LayerShell = '1.0';
        const Layer = imports.gi.Gtk4LayerShell;
        Layer.init_for_window(window);
        Layer.set_layer(window, Layer.Layer.OVERLAY);
        Layer.set_anchor(window, Layer.Edge.TOP, true);
        Layer.set_anchor(window, Layer.Edge.RIGHT, true);
        Layer.set_anchor(window, Layer.Edge.LEFT, false);
        Layer.set_anchor(window, Layer.Edge.BOTTOM, false);
        Layer.set_margin(window, Layer.Edge.TOP, 48);
        Layer.set_margin(window, Layer.Edge.RIGHT, 12);
        Layer.set_keyboard_mode(window, Layer.KeyboardMode.ON_DEMAND);
        Layer.set_namespace(window, 'circle-to-search');
    } catch (error) {
        printerr(`Circle to Search: top-right anchor unavailable: ${error}`);
    }
}

function makeView() {
    imports.gi.versions.WebKit = '6.0';
    const WebKit = imports.gi.WebKit;
    const dataDir = GLib.build_filenamev([
        GLib.get_user_data_dir(), 'circle-to-search', 'gemini']);
    const cacheDir = GLib.build_filenamev([
        GLib.get_user_cache_dir(), 'circle-to-search', 'gemini']);
    GLib.mkdir_with_parents(dataDir, 0o700);
    GLib.mkdir_with_parents(cacheDir, 0o700);

    let session;
    try {
        session = new WebKit.NetworkSession({
            data_directory: dataDir,
            cache_directory: cacheDir,
        });
    } catch (error) {
        session = new WebKit.NetworkSession(dataDir, cacheDir);
    }
    try {
        session.set_itp_enabled(false);
    } catch (error) {
        printerr(error);
    }
    try {
        session.set_persistent_credential_storage_enabled(true);
    } catch (error) {
        printerr(error);
    }
    const cookies = session.get_cookie_manager();
    cookies.set_persistent_storage(
        GLib.build_filenamev([dataDir, 'cookies.sqlite']),
        WebKit.CookiePersistentStorage.SQLITE);
    try {
        cookies.set_accept_policy(WebKit.CookieAcceptPolicy.ALWAYS);
    } catch (error) {
        printerr(error);
    }

    const manager = new WebKit.UserContentManager();
    const webView = new WebKit.WebView({
        network_session: session,
        user_content_manager: manager,
    });
    try {
        webView.get_settings().set_user_agent(
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36');
    } catch (error) {
        printerr(error);
    }
    webView.connect('load-changed', (_view, event) => {
        if (!WebKit.LoadEvent || event !== WebKit.LoadEvent.FINISHED)
            return;
        const uri = webView.get_uri() || '';
        if (uri.includes('gemini.google.com') && imagePath)
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 600, () => {
                drive(searchId);
                return GLib.SOURCE_REMOVE;
            });
    });
    webView._webkit = WebKit;
    return webView;
}

function submitImage(path) {
    imagePath = path;
    const id = ++searchId;
    reveal();
    if (!view)
        return;
    evaluate(RESET);
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, 200, () => {
        drive(id);
        return GLib.SOURCE_REMOVE;
    });
}

function drive(id) {
    if (id !== searchId || !view || !imagePath)
        return;
    if (drive._id !== id) {
        drive._id = id;
        drive._started = Date.now();
        drive._pastes = 0;
        drive._lastPaste = 0;
    }
    if (Date.now() - drive._started > 20000)
        return;
    evalText(PROBE, status => {
        if (id !== searchId)
            return;
        const state = String(status || '').replace(/"/g, '').trim();
        if (state === 'sent' || state === 'away') {
            if (state === 'away')
                schedule(id, 500);
            return;
        }
        if (state === 'focus' &&
            drive._pastes < 6 &&
            Date.now() - drive._lastPaste > 800) {
            drive._pastes += 1;
            drive._lastPaste = Date.now();
            putImageOnClipboard(imagePath);
            view.grab_focus();
            try {
                view.execute_editing_command('Paste');
            } catch (error) {
                printerr(`Circle to Search paste failed: ${error}`);
            }
        }
        schedule(id, 400);
    });
}

function schedule(id, delay) {
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, delay, () => {
        drive(id);
        return GLib.SOURCE_REMOVE;
    });
}

function putImageOnClipboard(path) {
    try {
        const texture = Gdk.Texture.new_from_filename(path);
        Gdk.Display.get_default().get_clipboard().set_content(
            Gdk.ContentProvider.new_for_value(texture));
    } catch (error) {
        printerr(`Circle to Search clipboard failed: ${error}`);
    }
}

function evaluate(script) {
    evalText(script, () => {});
}

function evalText(script, done) {
    if (!view) {
        done('');
        return;
    }
    try {
        view.evaluate_javascript(script, -1, null, null, null, (_view, result) => {
            let text = '';
            try {
                const value = view.evaluate_javascript_finish(result);
                if (value && typeof value.to_string === 'function')
                    text = value.to_string();
                else if (value != null)
                    text = String(value);
            } catch (error) {
                printerr(error);
            }
            done(text);
        });
    } catch (error) {
        printerr(error);
        done('');
    }
}

function installCss() {
    const provider = new Gtk.CssProvider();
    provider.load_from_string(CSS);
    Gtk.StyleContext.add_provider_for_display(
        Gdk.Display.get_default(),
        provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION);
}

const CSS = `
window.cts-sheet {
  background-color: #241f31;
  color: #f6f5f4;
  border-radius: 14px;
  border: 1px solid rgba(255, 255, 255, 0.08);
  box-shadow: 0 8px 28px rgba(0, 0, 0, 0.45);
}
.cts-head {
  margin: 6px 8px 4px 14px;
}
.cts-title {
  font-size: 15px;
  font-weight: 700;
  color: #f6f5f4;
}
button.cts-close {
  border-radius: 999px;
  min-width: 32px;
  min-height: 32px;
  padding: 0;
  background: transparent;
  color: #f6f5f4;
}
button.cts-close:hover {
  background: rgba(255, 255, 255, 0.08);
}
`;

const RESET = 'window.__ctsDone = false; window.__ctsPrompted = false;';

const PROBE = `
(() => {
    if (!(location.hostname || '').endsWith('gemini.google.com'))
        return 'away';
    const box = document.querySelector('div.ql-editor')
        || document.querySelector('rich-textarea [contenteditable="true"]')
        || document.querySelector('[aria-label="Enter a prompt here"]')
        || document.querySelector('[contenteditable="true"][role="textbox"]');
    if (!box)
        return 'wait';
    box.focus();
    if (window.__ctsDone)
        return 'sent';
    const scope = box.closest('form, rich-textarea, .input-area') || document.body;
    const attached = !!(
        scope.querySelector('img')
        || document.querySelector('button[aria-label*="Remove file" i]')
        || document.querySelector('button[aria-label*="Remove image" i]')
        || document.querySelector('img[src^="blob:"]')
    );
    const button = document.querySelector('button.send-button')
        || document.querySelector('button[aria-label="Send message"]')
        || document.querySelector('button[aria-label*="Send" i]');
    const disabled = !button || button.disabled || button.getAttribute('aria-disabled') === 'true';
    if (button && !disabled) {
        button.click();
        window.__ctsDone = true;
        return 'sent';
    }
    if (!attached)
        return 'focus';
    if (!(box.innerText || '').trim() && !window.__ctsPrompted) {
        window.__ctsPrompted = true;
        document.execCommand('insertText', false, 'What is this?');
        return 'typed';
    }
    return 'wait';
})()
`;

const FOCUS = `
(() => {
    const box = document.querySelector('div.ql-editor')
        || document.querySelector('rich-textarea [contenteditable="true"]')
        || document.querySelector('[aria-label="Enter a prompt here"]')
        || document.querySelector('[contenteditable="true"][role="textbox"]');
    if (box)
        box.focus();
})();
`;

const WATCH = `
(function () {
    if (window.__ctsWatch)
        return;
    window.__ctsWatch = true;
    setInterval(() => {
        if (!location.hostname.endsWith('gemini.google.com') || window.__ctsAsked)
            return;
        const box = document.querySelector('div.ql-editor')
            || document.querySelector('rich-textarea [contenteditable="true"]')
            || document.querySelector('[aria-label="Enter a prompt here"]')
            || document.querySelector('[contenteditable="true"][role="textbox"]');
        if (!box)
            return;
        box.focus();
        window.__ctsAsked = true;
        try {
            window.webkit.messageHandlers.cts.postMessage('paste');
        } catch (error) {}
    }, 400);
})();
`;

const SUBMIT = `
(() => {
    if (window.__ctsDone)
        return;
    const box = document.querySelector('div.ql-editor')
        || document.querySelector('rich-textarea [contenteditable="true"]')
        || document.querySelector('[aria-label="Enter a prompt here"]')
        || document.querySelector('[contenteditable="true"][role="textbox"]');
    const button = document.querySelector('button.send-button')
        || document.querySelector('button[aria-label="Send message"]')
        || document.querySelector('button[aria-label*="Send" i]');
    if (!button)
        return;
    const disabled = button.disabled || button.getAttribute('aria-disabled') === 'true';
    if (disabled) {
        if (box && !(box.innerText || '').trim() && !window.__ctsPrompted) {
            window.__ctsPrompted = true;
            box.focus();
            document.execCommand('insertText', false, 'What is this?');
        }
        return;
    }
    button.click();
    window.__ctsDone = true;
})();
`;

const invocation = [imports.system.programInvocationName || 'gemini-window'];
if (ARGV[0])
    invocation.push(ARGV[0]);
app.run(invocation);
