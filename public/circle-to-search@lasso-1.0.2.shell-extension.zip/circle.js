// SPDX-License-Identifier: GPL-2.0-or-later
//
// Circle mode sits inside GNOME's screenshot UI. The desktop on screen is the
// frozen stage texture ScreenshotUI already captured; the crop goes through
// Shell.Screenshot.composite_to_stream, which is what the shutter uses.

import Cairo from 'gi://cairo';
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Pango from 'gi://Pango';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Tooltip} from 'resource:///org/gnome/shell/ui/screenshot.js';

import {LENS_URL, searchUrl, translateUrl} from './engines.js';
import {recognize} from './ocr.js';

const TAP_TRAVEL = 18;
const TAP_W = 340;
const TAP_H = 220;

function uiLooksRight(ui) {
    return Boolean(
        ui &&
        ui._typeButtonContainer &&
        ui._selectionButton &&
        ui._screenButton &&
        ui._windowButton &&
        ui._areaSelector &&
        ui._stageScreenshot &&
        ui._primaryMonitorBin
    );
}

function cleanText(text) {
    return (text || '')
        .replace(/[ \t]+\n/g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

function openUri(uri) {
    const context = global.create_app_launch_context(0, -1);
    Gio.AppInfo.launch_default_for_uri(uri, context);
}

function playShutter() {
    try {
        const file = Gio.File.new_for_path(
            `${global.datadir}/sounds/screen-capture.oga`);
        global.display.get_sound_player().play_from_file(
            file, 'Circle to Search', null);
    } catch {
        try {
            global.display.get_sound_player().play_from_theme(
                'screen-capture', 'Circle to Search', null);
        } catch {
            // The sound theme is optional feedback.
        }
    }
}

class InkLayer {
    constructor(onStroke) {
        this._onStroke = onStroke;
        this._points = [];
        this._drawing = false;
        this._destroyed = false;
        this._canvas = null;
        this._canvasW = 0;
        this._canvasH = 0;

        this.actor = new St.Widget({
            name: 'cts-ink',
            style_class: 'cts-ink',
            reactive: false,
            visible: false,
            x_expand: true,
            y_expand: true,
        });

        this.actor.connect('notify::width', () => this._syncCanvas());
        this.actor.connect('notify::height', () => this._syncCanvas());
    }

    destroy() {
        this._destroyed = true;
        this.actor.destroy();
    }

    get drawing() {
        return this._drawing;
    }

    show() {
        this.actor.reactive = true;
        this.actor.set_cursor_type(Clutter.CursorType.CROSSHAIR);
        const parent = this.actor.get_parent();
        if (parent && parent.width > 1 && parent.height > 1) {
            this.actor.set_position(0, 0);
            this.actor.set_size(parent.width, parent.height);
        }
        this.actor.show();
        this._syncCanvas();
    }

    hide() {
        this.actor.reactive = false;
        this.actor.hide();
        this.clear();
    }

    clear() {
        this._points = [];
        this._drawing = false;
        this._invalidate();
    }

    hasInk() {
        return this._points.length > 0;
    }

    /// Stage-space box around the gesture. A tap becomes a region, not a speck.
    region() {
        const points = this._points;
        if (points.length === 0)
            return null;

        let minX = Infinity;
        let minY = Infinity;
        let maxX = -Infinity;
        let maxY = -Infinity;
        let travel = 0;
        for (let i = 0; i < points.length; i++) {
            const p = points[i];
            minX = Math.min(minX, p.x);
            minY = Math.min(minY, p.y);
            maxX = Math.max(maxX, p.x);
            maxY = Math.max(maxY, p.y);
            if (i > 0) {
                travel += Math.hypot(
                    p.x - points[i - 1].x,
                    p.y - points[i - 1].y);
            }
        }

        const boundsW = this.actor.width || global.stage.width;
        const boundsH = this.actor.height || global.stage.height;
        let box;
        if (points.length < 3 || travel < TAP_TRAVEL) {
            const cx = (minX + maxX) / 2;
            const cy = (minY + maxY) / 2;
            box = {
                x: cx - TAP_W / 2,
                y: cy - TAP_H / 2,
                w: TAP_W,
                h: TAP_H,
            };
        } else {
            box = {
                x: minX,
                y: minY,
                w: Math.max(1, maxX - minX),
                h: Math.max(1, maxY - minY),
            };
        }
        return clampBox(box, boundsW, boundsH);
    }

    beginAt(point) {
        this._points = [point];
        this._drawing = true;
        this._invalidate();
        this._onStroke('begin');
    }

    moveTo(point) {
        if (!this._drawing || !point)
            return;
        const prev = this._points[this._points.length - 1];
        if (!prev || Math.hypot(point.x - prev.x, point.y - prev.y) >= 1.5)
            this._points.push(point);
        this._invalidate();
    }

    finish() {
        if (!this._drawing)
            return false;
        this._drawing = false;
        this._invalidate();
        return this.hasInk();
    }

    _syncCanvas() {
        if (this._destroyed)
            return;
        const scale = this.actor.get_resource_scale?.() || 1;
        const logicalW = this.actor.width || global.stage.width || 1;
        const logicalH = this.actor.height || global.stage.height || 1;
        const w = Math.max(1, Math.round(logicalW * scale));
        const h = Math.max(1, Math.round(logicalH * scale));
        if (!this._canvas) {
            this._canvas = new Clutter.Canvas();
            this._canvas.connect('draw', (_canvas, cr, width, height) => {
                this._paint(cr, width, height);
                return true;
            });
            this.actor.set_content(this._canvas);
        }
        if (w !== this._canvasW || h !== this._canvasH) {
            this._canvasW = w;
            this._canvasH = h;
            this._canvas.set_size(w, h);
        } else {
            this._canvas.invalidate();
        }
    }

    _invalidate() {
        this._syncCanvas();
    }

    _paint(cr, width, height) {
        const actorW = Math.max(1, this.actor.width || width);
        const scale = width / actorW;
        cr.save();
        cr.setOperator(Cairo.Operator.CLEAR);
        cr.paint();
        cr.restore();
        cr.setOperator(Cairo.Operator.OVER);
        const stroke = this._points;
        if (stroke.length === 0)
            return;
        cr.setLineCap(Cairo.LineCap.ROUND);
        cr.setLineJoin(Cairo.LineJoin.ROUND);
        if (stroke.length === 1) {
            cr.setSourceRGBA(0.110, 0.443, 0.847, 0.96);
            cr.arc(stroke[0].x * scale, stroke[0].y * scale, 3.4 * scale, 0, Math.PI * 2);
            cr.fill();
            return;
        }
        cr.moveTo(stroke[0].x * scale, stroke[0].y * scale);
        for (let i = 1; i < stroke.length; i++)
            cr.lineTo(stroke[i].x * scale, stroke[i].y * scale);
        cr.setSourceRGBA(0.208, 0.518, 0.894, 0.35);
        cr.setLineWidth(13 * scale);
        cr.strokePreserve();
        cr.setSourceRGBA(0.110, 0.443, 0.847, 0.96);
        cr.setLineWidth(4.5 * scale);
        cr.stroke();
    }
}

function clampBox(box, boundsW, boundsH) {
    const x = Math.max(0, box.x);
    const y = Math.max(0, box.y);
    const right = Math.min(boundsW, box.x + box.w);
    const bottom = Math.min(boundsH, box.y + box.h);
    return {
        x,
        y,
        w: Math.max(1, right - x),
        h: Math.max(1, bottom - y),
    };
}

function padBox(box, pad, boundsW, boundsH) {
    return clampBox({
        x: box.x - pad,
        y: box.y - pad,
        w: box.w + pad * 2,
        h: box.h + pad * 2,
    }, boundsW, boundsH);
}

class ResultSheet {
    constructor(ui, onClose, onAgain, onLens) {
        this._ui = ui;
        this._onClose = onClose;
        this._onAgain = onAgain;
        this._onLens = onLens;

        this.actor = new St.Widget({
            name: 'cts-sheet',
            style_class: 'cts-sheet',
            reactive: true,
            visible: false,
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.END,
            layout_manager: new Clutter.BoxLayout({
                orientation: Clutter.Orientation.VERTICAL,
                spacing: 10,
            }),
        });

        const handleRow = new St.Widget({
            x_expand: true,
            layout_manager: new Clutter.BinLayout(),
        });
        handleRow.add_child(new St.Widget({
            style_class: 'cts-handle',
            x_align: Clutter.ActorAlign.CENTER,
        }));

        const head = new St.BoxLayout({style_class: 'cts-head', x_expand: true});
        this._preview = new St.Widget({style_class: 'cts-preview'});
        const titles = new St.BoxLayout({
            orientation: Clutter.Orientation.VERTICAL,
            style_class: 'cts-col',
            x_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
        });
        this._kicker = new St.Label({style_class: 'cts-muted'});
        this._title = new St.Label({style_class: 'cts-title', x_expand: true});
        this._title.clutter_text.line_wrap = true;
        this._title.clutter_text.line_wrap_mode = Pango.WrapMode.WORD_CHAR;
        titles.add_child(this._kicker);
        titles.add_child(this._title);
        head.add_child(this._preview);
        head.add_child(titles);

        this._body = new St.Label({x_expand: true});
        this._body.clutter_text.line_wrap = true;
        this._body.clutter_text.line_wrap_mode = Pango.WrapMode.WORD_CHAR;

        this._actions = new St.BoxLayout({style_class: 'cts-actions'});

        this.actor.add_child(handleRow);
        this.actor.add_child(head);
        this.actor.add_child(this._body);
        this.actor.add_child(this._actions);
    }

    destroy() {
        this.actor.destroy();
    }

    hide() {
        this.actor.remove_all_transitions();
        this.actor.hide();
    }

    showMessage(kicker, title, body) {
        this._fill({kicker, title, body, actions: this._idleActions()});
        this._reveal();
    }

    showReading(previewUri) {
        this._setPreview(previewUri);
        this._fill({
            kicker: 'From the screenshot',
            title: 'Reading the selection…',
            body: 'Cropped from the frozen frame.',
            actions: [],
        });
        this._reveal();
    }

    showResult({text, missing, failed, previewUri}) {
        this._setPreview(previewUri);
        const readable = cleanText(text);
        const shown = readable.length > 800
            ? `${readable.slice(0, 800).trim()}…`
            : readable;
        let kicker = 'Text in the selection';
        let title = shown || 'No text in this selection';
        let body = '';
        if (missing) {
            kicker = 'Text was not read';
            title = 'Tesseract is not installed';
            body = 'The crop is on the clipboard if copying is enabled. Install the tesseract-ocr package to read words on this computer, or paste the image into Lens.';
        } else if (failed) {
            kicker = 'Text was not read';
            title = 'Recognition failed';
            body = 'The crop is still available. You can paste it into Lens.';
        } else if (!shown) {
            body = 'Try circling words, or paste the image into Lens for a visual search.';
        } else {
            body = 'Nothing was uploaded. Search or translate only if you ask.';
        }

        const actions = [];
        if (readable && !missing && !failed) {
            actions.push({
                label: 'Search the web',
                primary: true,
                onClick: () => {},
                search: readable,
            });
            actions.push({
                label: 'Translate',
                onClick: () => openUri(translateUrl(readable)),
            });
            actions.push({
                label: 'Copy text',
                onClick: () => {
                    St.Clipboard.get_default().set_content(
                        St.ClipboardType.CLIPBOARD, 'text/plain', readable);
                },
            });
        }
        actions.push({
            label: 'Lens',
            primary: actions.length === 0,
            onClick: () => this._onLens(),
        });
        actions.push({label: 'Draw again', onClick: () => this._onAgain()});
        actions.push({label: 'Close', onClick: () => this._onClose()});

        this._pendingSearch = readable;
        this._fill({kicker, title, body, actions});
        this._reveal();
    }

    _idleActions() {
        return [
            {label: 'Draw again', onClick: () => this._onAgain()},
            {label: 'Close', onClick: () => this._onClose()},
        ];
    }

    _fill({kicker, title, body, actions}) {
        this._kicker.text = kicker;
        this._title.text = title;
        this._body.text = body || '';
        this._body.visible = Boolean(body);
        this._actions.destroy_all_children();
        for (const action of actions)
            this._actions.add_child(this._pill(action));
    }

    _pill(action) {
        const button = new St.Button({
            style_class: action.primary ? 'cts-pill cts-pill-primary' : 'cts-pill',
            can_focus: true,
        });
        button.set_child(new St.Label({text: action.label}));
        button.connect('clicked', () => {
            if (action.search)
                this._emitSearch(action.search);
            action.onClick();
        });
        return button;
    }

    _emitSearch(text) {
        // The engine is read by the session via the callback installed below.
        this._searchHandler?.(text);
    }

    setSearchHandler(handler) {
        this._searchHandler = handler;
    }

    _setPreview(uri) {
        this._preview.style = uri
            ? `background-image: url("${uri}");`
            : '';
    }

    _reveal() {
        const monitor = Main.layoutManager.primaryMonitor;
        const max = Math.max(300, (monitor?.width ?? 800) - 48);
        this.actor.width = Math.min(540, max);
        this.actor.remove_all_transitions();
        this.actor.show();
        this.actor.opacity = 255;
        this.actor.translation_y = 0;
        this._ui._primaryMonitorBin?.set_child_above_sibling(this.actor, null);
    }
}

export class CircleSession {
    constructor(settings) {
        this._settings = settings;
        this._ui = null;
        this._button = null;
        this._tooltip = null;
        this._hint = null;
        this._ink = null;
        this._sheet = null;
        this._ids = [];
        this._updating = false;
        this._destroyed = false;
        this._gen = 0;
        this._cancellable = null;
        this._originalCapture = null;
        this._wrappedCapture = null;
    }

    attach(ui) {
        if (this._destroyed || this._ui === ui && this._button)
            return;
        if (!uiLooksRight(ui)) {
            console.error(
                '[circle-to-search] Screenshot UI does not match GNOME 51. Circle was not added.');
            return;
        }
        this._ui = ui;

        const label = new St.Label({
            text: 'Circle',
            x_align: Clutter.ActorAlign.CENTER,
        });
        const box = new St.BoxLayout({
            orientation: Clutter.Orientation.VERTICAL,
            style_class: 'icon-label-button-container',
        });
        box.add_child(new St.Icon({
            icon_name: 'edit-find-symbolic',
            icon_size: 24,
        }));
        box.add_child(label);

        this._button = new St.Button({
            name: 'cts-circle-button',
            style_class: 'screenshot-ui-type-button',
            toggle_mode: true,
            x_expand: true,
            can_focus: true,
        });
        this._button.set_child(box);
        this._button.label_actor = label;
        ui._typeButtonContainer.insert_child_at_index(this._button, 1);

        this._tooltip = new Tooltip(this._button, {
            text: 'Circle to Search',
            style_class: 'screenshot-ui-tooltip',
            visible: false,
        });
        ui.add_child(this._tooltip);

        this._hint = new St.Label({
            style_class: 'cts-hint',
            text: 'Circle, scribble, or tap — release to search',
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.START,
            visible: false,
        });
        ui._primaryMonitorBin.add_child(this._hint);

        this._ink = new InkLayer(phase => {
            if (phase === 'begin')
                this._sheet?.hide();
        });
        ui.insert_child_above(this._ink.actor, ui._areaSelector);
        this._raiseInk();

        this._sheet = new ResultSheet(
            ui,
            () => ui.close(),
            () => this._again(),
            () => this._openLens());
        this._sheet.setSearchHandler(text => {
            const engine = this._settings.get_string('search-engine');
            openUri(searchUrl(engine, text));
        });
        ui._primaryMonitorBin.add_child(this._sheet.actor);

        this._connect(this._button, 'notify::checked', () => this._onCircle());
        for (const native of [ui._selectionButton, ui._screenButton, ui._windowButton])
            this._connect(native, 'notify::checked', () => this._onNative());
        this._connect(ui, 'captured-event', (_actor, event) => this._onCaptured(event));
        this._connect(ui, 'closed', () => this._onClosed());

        this._originalCapture = ui._onCaptureButtonClicked;
        const session = this;
        this._wrappedCapture = async function () {
            if (session._button?.checked) {
                if (session._ink?.hasInk())
                    await session.search();
                else
                    session._sheet?.showMessage(
                        'Circle to Search',
                        'Circle something first',
                        'Draw around it, scribble on the words, or tap. Release, or press Enter.');
                return;
            }
            return session._originalCapture.call(ui);
        };
        ui._onCaptureButtonClicked = this._wrappedCapture;
    }

    activate() {
        if (!this._ui || this._destroyed)
            return;
        if (!this._button)
            this.attach(this._ui);
        if (!this._button)
            return;
        this._button.toggle_mode = true;
        if (!this._button.checked)
            this._button.checked = true;
        else
            this._enter();
    }

    destroy() {
        this._destroyed = true;
        this._gen++;
        this._cancellable?.cancel();
        this._releasePointer();
        const ui = this._ui;
        if (ui && this._wrappedCapture &&
            ui._onCaptureButtonClicked === this._wrappedCapture)
            ui._onCaptureButtonClicked = this._originalCapture;
        for (const [obj, id] of this._ids) {
            try {
                obj.disconnect(id);
            } catch {
                // Actor may already be gone on shell shutdown.
            }
        }
        this._ids = [];
        this._ink?.destroy();
        this._sheet?.destroy();
        this._hint?.destroy();
        this._tooltip?.destroy();
        this._button?.destroy();
        this._ink = null;
        this._sheet = null;
        this._hint = null;
        this._tooltip = null;
        this._button = null;
    }

    async search() {
        const ui = this._ui;
        const ink = this._ink;
        if (!ui || !ink || this._destroyed || !ink.hasInk())
            return;

        let box = ink.region();
        if (!box)
            return;
        const pad = this._settings.get_int('stroke-padding');
        box = padBox(
            box,
            pad,
            ink.actor.width || global.stage.width,
            ink.actor.height || global.stage.height);

        const generation = ++this._gen;
        this._cancellable?.cancel();
        this._cancellable = new Gio.Cancellable();
        this._sheet.showMessage(
            'Circle to Search',
            'Searching…',
            'Cropping that part of the frozen screenshot.');
        this._flash(ui, box);

        let bytes;
        let uri = null;
        let file = null;
        try {
            bytes = await this._crop(ui, box);
            this._lastBytes = bytes;
            file = this._writeCache(bytes);
            uri = GLib.filename_to_uri(file.get_path(), null);
            if (this._settings.get_boolean('copy-image')) {
                St.Clipboard.get_default().set_content(
                    St.ClipboardType.CLIPBOARD, 'image/png', bytes);
            }
            if (this._settings.get_boolean('save-file'))
                this._saveCopy(file);
            playShutter();
        } catch (error) {
            logError(error, 'Circle to Search');
            if (generation === this._gen && !this._destroyed) {
                this._sheet.showMessage(
                    'Screenshot',
                    'Could not crop that region',
                    'The screenshot tool did not return a frame for this area.');
            }
            return;
        }

        if (generation !== this._gen || this._destroyed)
            return;

        this._sheet.showReading(uri);
        const lang = this._settings.get_string('tesseract-language');
        const result = await recognize(file.get_path(), lang, this._cancellable);
        if (generation !== this._gen || this._destroyed || result.cancelled)
            return;
        this._sheet.showResult({...result, previewUri: uri});
    }

    _openLens() {
        try {
            if (this._lastBytes) {
                St.Clipboard.get_default().set_content(
                    St.ClipboardType.CLIPBOARD, 'image/png', this._lastBytes);
            }
            openUri(LENS_URL);
            Main.notify(
                'Circle to Search',
                'Image copied. Paste it into Lens with Ctrl+V.');
        } catch (error) {
            logError(error, 'Circle to Search');
        }
    }

    _enter() {
        const ui = this._ui;
        if (!ui || !this._button)
            return;
        this._updating = true;
        try {
            this._button.toggle_mode = false;
            ui._selectionButton.checked = false;
            ui._screenButton.checked = false;
            ui._windowButton.checked = false;
            this._ink?.show();
            this._hint?.show();
            this._sheet?.hide();
            this._raiseInk();
            ui.set_cursor_type(Clutter.CursorType.CROSSHAIR);
        } finally {
            this._updating = false;
        }
    }

    _leave() {
        this._releasePointer();
        this._updating = true;
        try {
            this._ink?.hide();
            this._hint?.hide();
            this._ui?.set_cursor_type(Clutter.CursorType.INHERIT);
            const ui = this._ui;
            if (ui &&
                !ui._selectionButton.checked &&
                !ui._screenButton.checked &&
                !ui._windowButton.checked)
                ui._selectionButton.checked = true;
        } finally {
            this._updating = false;
        }
    }

    _again() {
        this._sheet?.hide();
        this._ink?.clear();
        this._ink?.show();
        this._hint?.show();
    }

    _onCircle() {
        if (this._updating || this._destroyed || !this._button)
            return;
        if (this._button.checked)
            this._enter();
        else
            this._leave();
    }

    _onNative() {
        if (this._updating || this._destroyed || !this._button?.checked)
            return;
        const ui = this._ui;
        const native = ui._selectionButton.checked ||
            ui._screenButton.checked ||
            ui._windowButton.checked;
        if (!native)
            return;
        this._updating = true;
        try {
            this._releasePointer();
            this._button.toggle_mode = true;
            this._button.checked = false;
            this._ink?.hide();
            this._hint?.hide();
        } finally {
            this._updating = false;
        }
    }

    _onClosed() {
        this._gen++;
        this._cancellable?.cancel();
        this._releasePointer();
        this._updating = true;
        try {
            this._ink?.hide();
            this._hint?.hide();
            this._sheet?.hide();
            if (this._button?.checked) {
                this._button.toggle_mode = true;
                this._button.checked = false;
            }
            const ui = this._ui;
            if (ui &&
                !ui._selectionButton.checked &&
                !ui._screenButton.checked &&
                !ui._windowButton.checked)
                ui._selectionButton.checked = true;
        } finally {
            this._updating = false;
        }
    }

    _connect(obj, signal, callback) {
        const id = obj.connect(signal, callback);
        this._ids.push([obj, id]);
    }

    _raiseInk() {
        const ui = this._ui;
        const ink = this._ink?.actor;
        const bin = ui?._primaryMonitorBin;
        if (!ui || !ink || !bin)
            return;
        if (ink.get_parent() === ui && bin.get_parent() === ui)
            ui.set_child_below_sibling(ink, bin);
    }

    _grabPointer() {
        if (this._pointerGrab || !this._ink)
            return;
        try {
            this._pointerGrab = global.stage.grab(this._ink.actor);
        } catch (error) {
            logError(error, 'Circle to Search');
        }
    }

    _releasePointer() {
        const grab = this._pointerGrab;
        this._pointerGrab = null;
        if (!grab)
            return;
        try {
            grab.dismiss();
        } catch {
            // The screenshot grab is already gone.
        }
    }

    _eventOnChrome(event) {
        let actor = event.get_source?.();
        const panel = this._ui?._panel;
        const close = this._ui?._closeButton;
        const sheet = this._sheet?.actor;
        while (actor && actor !== this._ui) {
            if (actor === panel || actor === close || actor === sheet)
                return true;
            actor = actor.get_parent();
        }
        return false;
    }

    _eventPoint(event) {
        const [x, y] = event.get_coords();
        if (!Number.isFinite(x) || !Number.isFinite(y))
            return null;
        const [originX, originY] = this._ink.actor.get_transformed_position();
        return {x: x - originX, y: y - originY};
    }

    _onCaptured(event) {
        if (this._destroyed || !this._button?.checked || !this._ink?.actor.visible)
            return Clutter.EVENT_PROPAGATE;

        const type = event.type();
        const press = type === Clutter.EventType.BUTTON_PRESS ||
            type === Clutter.EventType.TOUCH_BEGIN;
        const motion = type === Clutter.EventType.MOTION ||
            type === Clutter.EventType.TOUCH_UPDATE;
        const release = type === Clutter.EventType.BUTTON_RELEASE ||
            type === Clutter.EventType.TOUCH_END ||
            type === Clutter.EventType.TOUCH_CANCEL;
        if (!press && !motion && !release)
            return Clutter.EVENT_PROPAGATE;

        if (type === Clutter.EventType.BUTTON_PRESS ||
            type === Clutter.EventType.BUTTON_RELEASE) {
            if (event.get_button() !== Clutter.BUTTON_PRIMARY)
                return Clutter.EVENT_PROPAGATE;
        }

        if ((press || !this._ink.drawing) && this._eventOnChrome(event))
            return Clutter.EVENT_PROPAGATE;

        if (press) {
            const point = this._eventPoint(event);
            if (!point)
                return Clutter.EVENT_PROPAGATE;
            this._ink.beginAt(point);
            this._grabPointer();
            return Clutter.EVENT_STOP;
        }

        if (!this._ink.drawing)
            return Clutter.EVENT_PROPAGATE;

        const point = this._eventPoint(event);
        if (point)
            this._ink.moveTo(point);

        if (motion)
            return Clutter.EVENT_STOP;

        const drawn = this._ink.finish();
        this._releasePointer();
        if (drawn)
            this.search().catch(error => logError(error, 'Circle to Search'));
        return Clutter.EVENT_STOP;
    }

    async _crop(ui, box) {
        const content = ui._stageScreenshot.get_content?.();
        if (!content)
            throw new Error('Screenshot UI has no frozen frame');
        const texture = content.get_texture();
        const scale = ui._scale || 1;
        const stream = Gio.MemoryOutputStream.new_resizable();
        await Shell.Screenshot.composite_to_stream(
            texture,
            Math.round(box.x * scale),
            Math.round(box.y * scale),
            Math.max(1, Math.round(box.w * scale)),
            Math.max(1, Math.round(box.h * scale)),
            scale,
            null, 0, 0, 1,
            stream);
        stream.close(null);
        return stream.steal_as_bytes();
    }

    _writeCache(bytes) {
        const dir = GLib.build_filenamev([
            GLib.get_user_cache_dir(), 'circle-to-search']);
        GLib.mkdir_with_parents(dir, 0o700);
        const path = GLib.build_filenamev([dir, 'selection.png']);
        const file = Gio.File.new_for_path(path);
        const stream = file.replace(
            null, false, Gio.FileCreateFlags.REPLACE_DESTINATION, null);
        stream.write_bytes(bytes, null);
        stream.close(null);
        return file;
    }

    _saveCopy(src) {
        const pictures = GLib.get_user_special_dir(
            GLib.UserDirectory.DIRECTORY_PICTURES) || GLib.get_home_dir();
        const folder = GLib.build_filenamev([pictures, 'Screenshots']);
        GLib.mkdir_with_parents(folder, 0o755);
        const stamp = GLib.DateTime.new_now_local().format('%Y-%m-%d %H-%M-%S');
        const dest = Gio.File.new_for_path(GLib.build_filenamev([
            folder, `Circle Search from ${stamp}.png`]));
        src.copy(dest, Gio.FileCopyFlags.OVERWRITE, null, null);
    }

    _flash(ui, box) {
        const flash = new St.Widget({
            style: 'background-color: white;',
            opacity: 0,
            x: box.x,
            y: box.y,
            width: box.w,
            height: box.h,
        });
        ui.insert_child_above(flash, this._ink.actor);
        flash.ease({
            opacity: 170,
            duration: 70,
            mode: Clutter.AnimationMode.EASE_OUT_QUAD,
            onComplete: () => {
                flash.ease({
                    opacity: 0,
                    duration: 160,
                    mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                    onComplete: () => flash.destroy(),
                });
            },
        });
    }
}
