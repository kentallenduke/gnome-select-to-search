// SPDX-License-Identifier: GPL-2.0-or-later

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk?version=4.0';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {ENGINES, SHORTCUTS} from './engines.js';

export default class CircleToSearchPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        const page = new Adw.PreferencesPage({
            title: 'Circle to Search',
            icon_name: 'edit-find-symbolic',
        });
        window.add(page);

        const gesture = new Adw.PreferencesGroup({
            title: 'Gesture',
            description: 'Super+Print opens the screenshot tool in circle mode. Print still opens it normally — choose Circle, or press L. Draw, scribble, or tap, then release.',
        });
        page.add(gesture);

        const shortcuts = new Gtk.StringList();
        for (const [, label] of SHORTCUTS)
            shortcuts.append(label);
        const currentAccel = settings.get_strv('circle-to-search')[0] ?? '';
        let shortcutIndex = SHORTCUTS.findIndex(([accel]) => accel === currentAccel);
        if (shortcutIndex < 0)
            shortcutIndex = 0;
        const shortcutRow = new Adw.ComboRow({
            title: 'Shortcut',
            subtitle: 'Opens circle mode directly',
            model: shortcuts,
            selected: shortcutIndex,
        });
        shortcutRow.connect('notify::selected', () => {
            const accel = SHORTCUTS[shortcutRow.selected]?.[0];
            if (accel)
                settings.set_strv('circle-to-search', [accel]);
        });
        gesture.add(shortcutRow);

        const padding = new Gtk.Adjustment({
            lower: 0,
            upper: 160,
            step_increment: 4,
            page_increment: 20,
            value: settings.get_int('stroke-padding'),
        });
        const paddingRow = new Adw.SpinRow({
            title: 'Padding',
            subtitle: 'Extra pixels kept around the ink',
            adjustment: padding,
        });
        padding.connect('value-changed', () => {
            settings.set_int('stroke-padding', Math.round(padding.value));
        });
        gesture.add(paddingRow);

        const search = new Adw.PreferencesGroup({
            title: 'Search',
            description: 'Tesseract reads the crop on this computer. A browser opens only when you press Search, Translate, or Lens.',
        });
        page.add(search);

        const engines = new Gtk.StringList();
        for (const [, label] of ENGINES)
            engines.append(label);
        let engineIndex = ENGINES.findIndex(
            ([id]) => id === settings.get_string('search-engine'));
        if (engineIndex < 0)
            engineIndex = 0;
        const engineRow = new Adw.ComboRow({
            title: 'Search engine',
            model: engines,
            selected: engineIndex,
        });
        engineRow.connect('notify::selected', () => {
            const id = ENGINES[engineRow.selected]?.[0];
            if (id)
                settings.set_string('search-engine', id);
        });
        search.add(engineRow);

        const language = new Adw.EntryRow({
            title: 'Tesseract language',
        });
        settings.bind(
            'tesseract-language',
            language,
            'text',
            Gio.SettingsBindFlags.DEFAULT);
        search.add(language);

        const copyImage = new Adw.SwitchRow({
            title: 'Copy the image',
            subtitle: 'Put the crop on the clipboard as a PNG',
        });
        settings.bind('copy-image', copyImage, 'active', Gio.SettingsBindFlags.DEFAULT);
        search.add(copyImage);

        const saveFile = new Adw.SwitchRow({
            title: 'Save a PNG',
            subtitle: 'Also write Pictures/Screenshots',
        });
        settings.bind('save-file', saveFile, 'active', Gio.SettingsBindFlags.DEFAULT);
        search.add(saveFile);
    }
}
