// SPDX-License-Identifier: GPL-2.0-or-later

export const ENGINES = [
    ['google', 'Google'],
    ['duckduckgo', 'DuckDuckGo'],
    ['brave', 'Brave'],
    ['startpage', 'Startpage'],
];

export const SHORTCUTS = [
    ['<Super>Print', 'Super + Print Screen'],
    ['<Control>Print', 'Ctrl + Print Screen'],
    ['<Super><Shift>c', 'Super + Shift + C'],
    ['<Control><Shift>s', 'Ctrl + Shift + S'],
];

export const LENS_URL = 'https://lens.google.com/';

export function searchUrl(engine, text) {
    const q = encodeURIComponent(text);
    switch (engine) {
    case 'duckduckgo':
        return `https://duckduckgo.com/?q=${q}`;
    case 'brave':
        return `https://search.brave.com/search?q=${q}`;
    case 'startpage':
        return `https://www.startpage.com/sp/search?query=${q}`;
    default:
        return `https://www.google.com/search?q=${q}`;
    }
}

export function translateUrl(text) {
    const q = encodeURIComponent(text.slice(0, 1800));
    return `https://translate.google.com/?sl=auto&tl=en&op=translate&text=${q}`;
}
