// SPDX-License-Identifier: GPL-2.0-or-later

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class CircleToSearchPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const page = new Adw.PreferencesPage({
            title: 'Select to Search',
            icon_name: 'edit-find-symbolic',
        });
        window.add(page);

        const group = new Adw.PreferencesGroup();
        page.add(group);

        const settings = this.getSettings();
        const engines = new Gtk.StringList();
        for (const label of ['Gemini', 'Grok', 'ChatGPT', 'Claude'])
            engines.append(label);
        const provider = new Adw.ComboRow({
            title: 'Search with',
            subtitle: 'Where the screenshot is sent',
            model: engines,
        });
        const ids = ['gemini', 'grok', 'chatgpt', 'claude'];
        const current = settings.get_string('search-engine');
        const selected = ids.indexOf(current);
        provider.set_selected(selected < 0 ? 0 : selected);
        provider.connect('notify::selected', () => {
            const index = provider.get_selected();
            if (index >= 0 && index < ids.length)
                settings.set_string('search-engine', ids[index]);
        });
        group.add(provider);

        const browser = new Adw.SwitchRow({
            title: 'Open Claude and Grok in the browser',
            subtitle: 'Their sign-in pages block the built-in window. The screenshot is copied so you can paste it',
        });
        settings.bind(
            'external-login',
            browser,
            'active',
            Gio.SettingsBindFlags.DEFAULT);
        group.add(browser);

        const topBar = new Adw.SwitchRow({
            title: 'Show in the top bar',
            subtitle: 'Adds a Select to Search button next to the other status icons',
        });
        this.getSettings().bind(
            'show-top-bar',
            topBar,
            'active',
            Gio.SettingsBindFlags.DEFAULT);
        group.add(topBar);

        const shake = new Adw.SwitchRow({
            title: 'Shake to search',
            subtitle: 'Shake the pointer to open Select to Search',
        });
        settings.bind(
            'shake-enabled',
            shake,
            'active',
            Gio.SettingsBindFlags.DEFAULT);
        group.add(shake);

        const sensitivity = new Adw.ActionRow({
            title: 'Shake sensitivity',
            subtitle: 'Higher triggers more easily',
        });
        const scale = new Gtk.Scale({
            orientation: Gtk.Orientation.HORIZONTAL,
            draw_value: true,
            digits: 0,
            hexpand: true,
            width_request: 180,
            valign: Gtk.Align.CENTER,
            adjustment: new Gtk.Adjustment({
                lower: 1,
                upper: 100,
                step_increment: 1,
                page_increment: 10,
            }),
        });
        settings.bind(
            'shake-sensitivity',
            scale.get_adjustment(),
            'value',
            Gio.SettingsBindFlags.DEFAULT);
        settings.bind(
            'shake-enabled',
            sensitivity,
            'sensitive',
            Gio.SettingsBindFlags.DEFAULT);
        sensitivity.add_suffix(scale);
        group.add(sensitivity);
    }
}
