// SPDX-License-Identifier: GPL-2.0-or-later
//
// Circle mode sits inside GNOME's screenshot UI. The desktop on screen is the
// frozen stage texture ScreenshotUI already captured; the crop goes through
// Shell.Screenshot.composite_to_stream, which is what the shutter uses.

import Cairo from 'gi://cairo';
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Tooltip} from 'resource:///org/gnome/shell/ui/screenshot.js';


const TAP_TRAVEL = 18;
const TAP_W = 340;
const TAP_H = 220;

function uiLooksRight(ui) {
    return Boolean(
        ui &&
        ui._typeButtonContainer &&
        ui._selectionButton &&
        ui._screenButton &&
        ui._windowButton &&
        ui._areaSelector &&
        ui._stageScreenshot &&
        ui._primaryMonitorBin
    );
}

function playShutter() {
    try {
        const file = Gio.File.new_for_path(
            `${global.datadir}/sounds/screen-capture.oga`);
        global.display.get_sound_player().play_from_file(
            file, 'Circle to Search', null);
    } catch {
        try {
            global.display.get_sound_player().play_from_theme(
                'screen-capture', 'Circle to Search', null);
        } catch {
            // The sound theme is optional feedback.
        }
    }
}

class InkLayer {
    constructor(onStroke) {
        this._onStroke = onStroke;
        this._points = [];
        this._drawing = false;
        this._destroyed = false;
        this._grab = null;

        // Clutter.Canvas was removed in Mutter 51. St.DrawingArea is the
        // Cairo surface the shell itself still paints into.
        this.actor = new St.DrawingArea({
            name: 'cts-ink',
            style_class: 'cts-ink',
            reactive: false,
            visible: false,
            x_expand: true,
            y_expand: true,
        });
        this.actor.connect('repaint', () => this._repaint());

        this._pan = new Clutter.PanGesture();
        this._pan.set_begin_threshold(0);
        this._pan.connect('recognize', () => this._onPanBegin());
        this._pan.connect('pan-update', () => this._onPanUpdate());
        this._pan.connect('end', () => this._onPanEnd());
        this._pan.connect('cancel', () => this._onPanCancel());
        this.actor.add_action(this._pan);
        this.actor.connect('event', (_actor, event) => this._onEvent(event));
    }

    destroy() {
        this._destroyed = true;
        this._releaseGrab();
        this.actor.destroy();
    }

    get drawing() {
        return this._drawing;
    }

    show() {
        this.actor.reactive = true;
        try {
            this.actor.set_cursor_type(Clutter.CursorType.CROSSHAIR);
        } catch (error) {
            logError(error, 'Circle to Search');
        }
        this.actor.show();
        this._queueRepaint();
    }

    hide() {
        this._releaseGrab();
        this.actor.reactive = false;
        this.actor.hide();
        this.clear();
    }

    clear() {
        this._points = [];
        this._drawing = false;
        this._queueRepaint();
    }

    cancel() {
        this._releaseGrab();
        this._drawing = false;
        this.clear();
    }

    hasInk() {
        return this._points.length > 0;
    }

    /// Stage-space box around the gesture. A tap becomes a region, not a speck.
    region() {
        const points = this._points;
        if (points.length === 0)
            return null;

        let minX = Infinity;
        let minY = Infinity;
        let maxX = -Infinity;
        let maxY = -Infinity;
        let travel = 0;
        for (let i = 0; i < points.length; i++) {
            const p = points[i];
            minX = Math.min(minX, p.x);
            minY = Math.min(minY, p.y);
            maxX = Math.max(maxX, p.x);
            maxY = Math.max(maxY, p.y);
            if (i > 0) {
                travel += Math.hypot(
                    p.x - points[i - 1].x,
                    p.y - points[i - 1].y);
            }
        }

        const boundsW = global.stage.width;
        const boundsH = global.stage.height;
        let box;
        if (points.length < 3 || travel < TAP_TRAVEL) {
            const cx = (minX + maxX) / 2;
            const cy = (minY + maxY) / 2;
            box = {
                x: cx - TAP_W / 2,
                y: cy - TAP_H / 2,
                w: TAP_W,
                h: TAP_H,
            };
        } else {
            box = {
                x: minX,
                y: minY,
                w: Math.max(1, maxX - minX),
                h: Math.max(1, maxY - minY),
            };
        }
        return clampBox(box, boundsW, boundsH);
    }

    _centroid() {
        const point = this._pan.get_centroid_abs();
        return {x: point.x, y: point.y};
    }

    _onPanBegin() {
        const point = this._centroid();
        this._points = [point];
        this._drawing = true;
        this._startPulse();
        this._queueRepaint();
        if (!this._grab) {
            try {
                this._grab = global.stage.grab(this.actor);
            } catch (error) {
                logError(error, 'Circle to Search');
            }
        }
        this._onStroke('begin');
    }

    _onPanUpdate() {
        if (!this._drawing)
            return;
        const next = this._centroid();
        const prev = this._points[this._points.length - 1];
        if (!prev || Math.hypot(next.x - prev.x, next.y - prev.y) >= 1.5)
            this._points.push(next);
        this._queueRepaint();
    }

    _onPanEnd() {
        if (!this._drawing) {
            this._releaseGrab();
            return;
        }
        this._onPanUpdate();
        this._drawing = false;
        this._releaseGrab();
        this._queueRepaint();
        this._onStroke('end');
    }

    _onPanCancel() {
        if (this._drawing && this._points.length > 0)
            this._onPanEnd();
        else {
            this._releaseGrab();
            this.clear();
        }
    }

    _onEvent(event) {
        try {
            const type = event.type();
            const release = type === Clutter.EventType.BUTTON_RELEASE ||
                type === Clutter.EventType.TOUCH_END;
            if (release && this._drawing)
                this._onPanEnd();
        } catch (error) {
            logError(error, 'Circle to Search');
        }
        return Clutter.EVENT_PROPAGATE;
    }

    _releaseGrab() {
        const grab = this._grab;
        this._grab = null;
        if (!grab)
            return;
        try {
            grab.dismiss();
        } catch {
            // The screenshot UI already dropped the grab.
        }
    }

    _startPulse() {
        if (this._pulseId)
            return;
        this._pulseId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 32, () => {
            if (this._destroyed || this._points.length === 0) {
                this._pulseId = 0;
                return GLib.SOURCE_REMOVE;
            }
            this._queueRepaint();
            return GLib.SOURCE_CONTINUE;
        });
    }

    _queueRepaint() {
        if (this._destroyed)
            return;
        if (this.actor.width <= 0 || this.actor.height <= 0)
            return;
        try {
            this.actor.queue_repaint();
        } catch (error) {
            logError(error, 'Circle to Search');
        }
    }

    _repaint() {
        const cr = this.actor.get_context();
        if (!cr)
            return;
        try {
            const [originX, originY] = this.actor.get_transformed_position();
            const stroke = this._points.map(point => ({
                x: point.x - originX,
                y: point.y - originY,
            }));
            if (stroke.length === 0)
                return;
            cr.setOperator(Cairo.Operator.OVER);
            cr.setLineCap(Cairo.LineCap.ROUND);
            cr.setLineJoin(Cairo.LineJoin.ROUND);
            if (stroke.length === 1) {
                const pulse = 0.5 + 0.5 * Math.sin(Date.now() / 140);
                const [red, green, blue] = googleColor((Date.now() / 900) % 1);
                cr.setSourceRGBA(red, green, blue, 0.18 + pulse * 0.22);
                cr.arc(stroke[0].x, stroke[0].y, 16 + pulse * 18, 0, Math.PI * 2);
                cr.fill();
                cr.setSourceRGBA(1, 1, 1, 1);
                cr.arc(stroke[0].x, stroke[0].y, 4, 0, Math.PI * 2);
                cr.fill();
                return;
            }
            const now = Date.now();
            const pulse = 0.5 + 0.5 * Math.sin(now / 140);
            paintGlow(cr, stroke, 28 + pulse * 18, 0.05 + pulse * 0.1);
            paintGlow(cr, stroke, 14 + pulse * 8, 0.14 + pulse * 0.16);
            paintGlow(cr, stroke, 7, 0.26 + pulse * 0.22);
            paintEnergy(cr, stroke, (now / 650) % 1);
            cr.setSourceRGBA(1, 1, 1, 0.95);
            cr.setLineWidth(4.5);
            cr.moveTo(stroke[0].x, stroke[0].y);
            for (let i = 1; i < stroke.length; i++)
                cr.lineTo(stroke[i].x, stroke[i].y);
            cr.stroke();
        } finally {
            cr.$dispose();
        }
    }
}

function paintEnergy(cr, stroke, head) {
    let total = 0;
    const lengths = [];
    for (let i = 1; i < stroke.length; i++) {
        const length = Math.hypot(
            stroke[i].x - stroke[i - 1].x,
            stroke[i].y - stroke[i - 1].y);
        lengths.push(length);
        total += length;
    }
    if (total <= 0)
        return;
    let walked = 0;
    for (let i = 1; i < stroke.length; i++) {
        const length = lengths[i - 1];
        const t = (walked + length / 2) / total;
        walked += length;
        let dist = Math.abs(t - head);
        dist = Math.min(dist, 1 - dist);
        if (dist > 0.09)
            continue;
        const hot = 1 - dist / 0.09;
        const [red, green, blue] = googleColor(t + head);
        cr.setSourceRGBA(red, green, blue, 0.45 * hot);
        cr.setLineWidth(8 + 16 * hot);
        cr.moveTo(stroke[i - 1].x, stroke[i - 1].y);
        cr.lineTo(stroke[i].x, stroke[i].y);
        cr.stroke();
        cr.setSourceRGBA(1, 1, 1, 0.95 * hot);
        cr.setLineWidth(2.5);
        cr.moveTo(stroke[i - 1].x, stroke[i - 1].y);
        cr.lineTo(stroke[i].x, stroke[i].y);
        cr.stroke();
    }
}

function paintGlow(cr, stroke, width, alpha) {
    cr.setLineWidth(width);
    for (let i = 1; i < stroke.length; i++) {
        const [red, green, blue] = googleColor((i - 1) / (stroke.length - 1));
        cr.setSourceRGBA(red, green, blue, alpha);
        cr.moveTo(stroke[i - 1].x, stroke[i - 1].y);
        cr.lineTo(stroke[i].x, stroke[i].y);
        cr.stroke();
    }
}

const GOOGLE_COLORS = [
    [0.259, 0.522, 0.957],
    [0.918, 0.263, 0.208],
    [0.984, 0.737, 0.020],
    [0.204, 0.659, 0.325],
];

function googleColor(t) {
    const scaled = ((t % 1) + 1) % 1 * GOOGLE_COLORS.length;
    const index = Math.floor(scaled) % GOOGLE_COLORS.length;
    const next = (index + 1) % GOOGLE_COLORS.length;
    const mix = scaled - Math.floor(scaled);
    const from = GOOGLE_COLORS[index];
    const to = GOOGLE_COLORS[next];
    return [
        from[0] + (to[0] - from[0]) * mix,
        from[1] + (to[1] - from[1]) * mix,
        from[2] + (to[2] - from[2]) * mix,
    ];
}

function clampBox(box, boundsW, boundsH) {
    const x = Math.max(0, box.x);
    const y = Math.max(0, box.y);
    const right = Math.min(boundsW, box.x + box.w);
    const bottom = Math.min(boundsH, box.y + box.h);
    return {
        x,
        y,
        w: Math.max(1, right - x),
        h: Math.max(1, bottom - y),
    };
}

function padBox(box, pad, boundsW, boundsH) {
    return clampBox({
        x: box.x - pad,
        y: box.y - pad,
        w: box.w + pad * 2,
        h: box.h + pad * 2,
    }, boundsW, boundsH);
}

export class CircleSession {
    constructor(settings, dir) {
        this._settings = settings;
        this._dir = dir;
        this._ui = null;
        this._button = null;
        this._tooltip = null;
        this._hint = null;
        this._ink = null;
        this._ids = [];
        this._updating = false;
        this._destroyed = false;
        this._gen = 0;
        this._cancellable = null;
        this._originalCapture = null;
        this._wrappedCapture = null;
    }

    attach(ui) {
        if (this._destroyed || this._ui === ui && this._button)
            return;
        if (!uiLooksRight(ui)) {
            console.error(
                '[circle-to-search] Screenshot UI does not match GNOME 51. Circle was not added.');
            return;
        }
        this._ui = ui;

        const label = new St.Label({
            text: 'Circle',
            x_align: Clutter.ActorAlign.CENTER,
        });
        const box = new St.BoxLayout({
            orientation: Clutter.Orientation.VERTICAL,
            style_class: 'icon-label-button-container',
        });
        box.add_child(new St.Icon({
            icon_name: 'edit-find-symbolic',
            icon_size: 24,
        }));
        box.add_child(label);

        this._button = new St.Button({
            name: 'cts-circle-button',
            style_class: 'screenshot-ui-type-button',
            toggle_mode: true,
            x_expand: true,
            can_focus: true,
        });
        this._button.set_child(box);
        this._button.label_actor = label;
        ui._typeButtonContainer.insert_child_at_index(this._button, 1);

        this._tooltip = new Tooltip(this._button, {
            text: 'Circle to Search',
            style_class: 'screenshot-ui-tooltip',
            visible: false,
        });
        ui.add_child(this._tooltip);

        this._hint = new St.Label({
            style_class: 'cts-hint',
            text: 'Release to search with Gemini',
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.START,
            visible: false,
        });
        ui._primaryMonitorBin.add_child(this._hint);

        this._ink = new InkLayer(phase => {
            if (phase === 'end')
                this.search().catch(error => logError(error, 'Circle to Search'));
        });
        ui.insert_child_above(this._ink.actor, ui._areaSelector);
        this._raiseInk();

        this._connect(this._button, 'notify::checked', () => this._onCircle());
        for (const native of [ui._selectionButton, ui._screenButton, ui._windowButton])
            this._connect(native, 'notify::checked', () => this._onNative());
        this._connect(ui, 'closed', () => this._onClosed());

        this._originalCapture = ui._onCaptureButtonClicked;
        const session = this;
        this._wrappedCapture = async function () {
            if (session._button?.checked) {
                if (session._ink?.hasInk())
                    await session.search();
                return;
            }
            return session._originalCapture.call(ui);
        };
        ui._onCaptureButtonClicked = this._wrappedCapture;
    }

    activate() {
        if (!this._ui || this._destroyed)
            return;
        if (!this._button)
            this.attach(this._ui);
        if (!this._button)
            return;
        this._button.toggle_mode = true;
        if (!this._button.checked)
            this._button.checked = true;
        else
            this._enter();
    }

    destroy() {
        this._destroyed = true;
        this._gen++;
        this._cancellable?.cancel();
        this._ink?.cancel();
        const ui = this._ui;
        if (ui && this._wrappedCapture &&
            ui._onCaptureButtonClicked === this._wrappedCapture)
            ui._onCaptureButtonClicked = this._originalCapture;
        for (const [obj, id] of this._ids) {
            try {
                obj.disconnect(id);
            } catch {
                // Actor may already be gone on shell shutdown.
            }
        }
        this._ids = [];
        this._ink?.destroy();
        this._hint?.destroy();
        this._tooltip?.destroy();
        this._button?.destroy();
        this._ink = null;
        this._hint = null;
        this._tooltip = null;
        this._button = null;
    }

    async search() {
        const ui = this._ui;
        const ink = this._ink;
        if (!ui || !ink || this._destroyed || !ink.hasInk())
            return;

        let box = ink.region();
        if (!box)
            return;
        const pad = this._settings.get_int('stroke-padding');
        box = padBox(
            box,
            pad,
            ink.actor.width || global.stage.width,
            ink.actor.height || global.stage.height);

        const generation = ++this._gen;
        this._flash(ui, box);

        let imagePath = null;
        try {
            const bytes = await this._crop(ui, box);
            this._lastBytes = bytes;
            const file = this._writeCache(bytes);
            imagePath = file.get_path();
            if (this._settings.get_boolean('copy-image')) {
                St.Clipboard.get_default().set_content(
                    St.ClipboardType.CLIPBOARD, 'image/png', bytes);
            }
            if (this._settings.get_boolean('save-file'))
                this._saveCopy(file);
            playShutter();
        } catch (error) {
            logError(error, 'Circle to Search');
        }

        if (generation !== this._gen || this._destroyed)
            return;
        this._releaseScreenshot();
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 200, () => {
            if (!this._destroyed)
                this._openGemini(imagePath);
            return GLib.SOURCE_REMOVE;
        });
    }

    _openGemini(imagePath) {
        const script = this._dir
            ? GLib.build_filenamev([this._dir, 'gemini-window.js'])
            : null;
        if (!script || !Gio.File.new_for_path(script).query_exists(null)) {
            Main.notify('Circle to Search', 'The Gemini window is missing from the extension.');
            return;
        }
        const gjs = GLib.find_program_in_path('gjs') || '/usr/bin/gjs';
        this._restartHelperIfNeeded();
        const parts = [gjs, script];
        if (imagePath)
            parts.push(imagePath);
        const command = parts.map(part => GLib.shell_quote(part)).join(' ');
        try {
            const info = Gio.AppInfo.create_from_commandline(
                command,
                'Gemini',
                Gio.AppInfoCreateFlags.SUPPORTS_STARTUP_NOTIFICATION);
            info.launch([], global.create_app_launch_context(0, -1));
        } catch (error) {
            logError(error, 'Circle to Search');
            Main.notify('Circle to Search', `Could not open Gemini: ${error.message || error}`);
        }
    }

    _restartHelperIfNeeded() {
        const stampPath = GLib.build_filenamev([
            GLib.get_user_cache_dir(), 'circle-to-search', 'helper-version']);
        GLib.mkdir_with_parents(GLib.path_get_dirname(stampPath), 0o700);
        let previous = '';
        try {
            const [, bytes] = GLib.file_get_contents(stampPath);
            previous = new TextDecoder().decode(bytes).trim();
        } catch {
            previous = '';
        }
        if (previous === '12')
            return;
        try {
            GLib.spawn_command_line_sync('pkill -f gemini-window.js');
        } catch {
            // The previous helper was not running.
        }
        GLib.file_set_contents(stampPath, '12');
    }

    _enter() {
        const ui = this._ui;
        if (!ui || !this._button)
            return;
        this._updating = true;
        try {
            this._button.toggle_mode = false;
            ui._selectionButton.checked = false;
            ui._screenButton.checked = false;
            ui._windowButton.checked = false;
            this._ink?.show();
            this._hint?.show();
            this._raiseInk();
            ui.set_cursor_type(Clutter.CursorType.CROSSHAIR);
        } finally {
            this._updating = false;
        }
    }

    _leave() {
        this._ink?.cancel();
        this._updating = true;
        try {
            this._ink?.hide();
            this._hint?.hide();
            this._ui?.set_cursor_type(Clutter.CursorType.INHERIT);
            const ui = this._ui;
            if (ui &&
                !ui._selectionButton.checked &&
                !ui._screenButton.checked &&
                !ui._windowButton.checked)
                ui._selectionButton.checked = true;
        } finally {
            this._updating = false;
        }
    }

    _releaseScreenshot() {
        const ui = this._ui;
        if (!ui?.visible)
            return;
        this._releasing = true;
        try {
            ui.close(true);
        } catch (error) {
            logError(error, 'Circle to Search');
        } finally {
            this._releasing = false;
        }
    }

    _onCircle() {
        if (this._updating || this._destroyed || !this._button)
            return;
        if (this._button.checked)
            this._enter();
        else
            this._leave();
    }

    _onNative() {
        if (this._updating || this._destroyed || !this._button?.checked)
            return;
        const ui = this._ui;
        const native = ui._selectionButton.checked ||
            ui._screenButton.checked ||
            ui._windowButton.checked;
        if (!native)
            return;
        this._updating = true;
        try {
            this._ink?.cancel();
            this._button.toggle_mode = true;
            this._button.checked = false;
            this._ink?.hide();
            this._hint?.hide();
        } finally {
            this._updating = false;
        }
    }

    _onClosed() {
        if (!this._releasing) {
            this._gen++;
            this._cancellable?.cancel();
        }
        this._ink?.cancel();
        this._updating = true;
        try {
            this._ink?.hide();
            this._hint?.hide();
            if (this._button?.checked) {
                this._button.toggle_mode = true;
                this._button.checked = false;
            }
            const ui = this._ui;
            if (ui &&
                !ui._selectionButton.checked &&
                !ui._screenButton.checked &&
                !ui._windowButton.checked)
                ui._selectionButton.checked = true;
        } finally {
            this._updating = false;
        }
    }

    _connect(obj, signal, callback) {
        const id = obj.connect(signal, callback);
        this._ids.push([obj, id]);
    }

    _raiseInk() {
        const ui = this._ui;
        const ink = this._ink?.actor;
        const bin = ui?._primaryMonitorBin;
        if (!ui || !ink || !bin)
            return;
        if (ink.get_parent() === ui && bin.get_parent() === ui)
            ui.set_child_below_sibling(ink, bin);
    }

    async _crop(ui, box) {
        const content = ui._stageScreenshot.get_content?.();
        if (!content)
            throw new Error('Screenshot UI has no frozen frame');
        const texture = content.get_texture();
        const scale = ui._scale || 1;
        const stream = Gio.MemoryOutputStream.new_resizable();
        await Shell.Screenshot.composite_to_stream(
            texture,
            Math.round(box.x * scale),
            Math.round(box.y * scale),
            Math.max(1, Math.round(box.w * scale)),
            Math.max(1, Math.round(box.h * scale)),
            scale,
            null, 0, 0, 1,
            stream);
        stream.close(null);
        return stream.steal_as_bytes();
    }

    _writeCache(bytes) {
        const dir = GLib.build_filenamev([
            GLib.get_user_cache_dir(), 'circle-to-search']);
        GLib.mkdir_with_parents(dir, 0o700);
        const stamp = `${Date.now()}`;
        const path = GLib.build_filenamev([dir, `selection-${stamp}.png`]);
        const file = Gio.File.new_for_path(path);
        const stream = file.replace(
            null, false, Gio.FileCreateFlags.REPLACE_DESTINATION, null);
        stream.write_bytes(bytes, null);
        stream.close(null);
        return file;
    }

    _saveCopy(src) {
        const pictures = GLib.get_user_special_dir(
            GLib.UserDirectory.DIRECTORY_PICTURES) || GLib.get_home_dir();
        const folder = GLib.build_filenamev([pictures, 'Screenshots']);
        GLib.mkdir_with_parents(folder, 0o755);
        const stamp = GLib.DateTime.new_now_local().format('%Y-%m-%d %H-%M-%S');
        const dest = Gio.File.new_for_path(GLib.build_filenamev([
            folder, `Circle Search from ${stamp}.png`]));
        src.copy(dest, Gio.FileCopyFlags.OVERWRITE, null, null);
    }

    _flash(ui, box) {
        const flash = new St.Widget({
            style: 'background-color: white;',
            opacity: 0,
            x: box.x,
            y: box.y,
            width: box.w,
            height: box.h,
        });
        ui.insert_child_above(flash, this._ink.actor);
        flash.ease({
            opacity: 170,
            duration: 70,
            mode: Clutter.AnimationMode.EASE_OUT_QUAD,
            onComplete: () => {
                flash.ease({
                    opacity: 0,
                    duration: 160,
                    mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                    onComplete: () => flash.destroy(),
                });
            },
        });
    }
}
