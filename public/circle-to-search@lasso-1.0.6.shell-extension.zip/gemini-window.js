#!/usr/bin/env gjs
// Own Gemini window. Not a browser. Pastes the circled image and sends it.

imports.gi.versions.Gtk = '4.0';
imports.gi.versions.Gdk = '4.0';
imports.gi.versions.WebKit = '6.0';

const {GLib, Gio, Gtk, Gdk} = imports.gi;

const GEMINI = 'https://gemini.google.com/app';
const imagePath = ARGV[0] || '';

GLib.set_prgname('Gemini');

const app = new Gtk.Application({
    application_id: 'org.gnome.circle_to_search.Gemini',
    flags: Gio.ApplicationFlags.NON_UNIQUE,
});

app.connect('activate', () => {
    let WebKit;
    try {
        WebKit = imports.gi.WebKit;
    } catch (error) {
        const win = new Gtk.ApplicationWindow({
            application: app,
            title: 'Gemini',
            default_width: 520,
            default_height: 180,
        });
        win.set_child(new Gtk.Label({
            label: 'This window needs WebKitGTK 6.\nInstall webkitgtk6.0, or gir1.2-webkit-6.0, and try again.',
            wrap: true,
            margin_top: 24,
            margin_bottom: 24,
            margin_start: 24,
            margin_end: 24,
        }));
        win.present();
        return;
    }

    const dataDir = GLib.build_filenamev([
        GLib.get_user_data_dir(), 'circle-to-search', 'gemini']);
    const cacheDir = GLib.build_filenamev([
        GLib.get_user_cache_dir(), 'circle-to-search', 'gemini']);
    GLib.mkdir_with_parents(dataDir, 0o700);
    GLib.mkdir_with_parents(cacheDir, 0o700);

    const manager = new WebKit.UserContentManager();
    try {
        manager.register_script_message_handler('cts', null);
    } catch (error) {
        manager.register_script_message_handler('cts');
    }
    manager.add_script(new WebKit.UserScript(
        SOURCE,
        WebKit.UserContentInjectedFrames.TOP_FRAME,
        WebKit.UserScriptInjectionTime.END,
        null,
        null));

    const session = new WebKit.NetworkSession(dataDir, cacheDir);
    const view = new WebKit.WebView({
        network_session: session,
        user_content_manager: manager,
    });
    const settings = view.get_settings();
    settings.set_user_agent(
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36');

    const win = new Gtk.ApplicationWindow({
        application: app,
        title: 'Gemini',
        default_width: 1040,
        default_height: 760,
    });
    win.set_child(view);

    let pasted = false;
    manager.connect('script-message-received::cts', () => {
        if (pasted || !imagePath)
            return;
        pasted = true;
        win.present();
        view.grab_focus();
        putImageOnClipboard(imagePath);
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 200, () => {
            try {
                view.execute_editing_command(WebKit.EDITING_COMMAND_PASTE);
            } catch (error) {
                printerr(`Circle to Search paste failed: ${error}`);
            }
            let tries = 0;
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 500, () => {
                tries += 1;
                evaluate(view, SUBMIT);
                return tries < 16 ? GLib.SOURCE_CONTINUE : GLib.SOURCE_REMOVE;
            });
            return GLib.SOURCE_REMOVE;
        });
    });

    view.load_uri(GEMINI);
    win.present();
    if (imagePath)
        putImageOnClipboard(imagePath);
});

function putImageOnClipboard(path) {
    try {
        const texture = Gdk.Texture.new_from_filename(path);
        const clipboard = Gdk.Display.get_default().get_clipboard();
        clipboard.set_content(Gdk.ContentProvider.new_for_value(texture));
    } catch (error) {
        printerr(`Circle to Search clipboard failed: ${error}`);
    }
}

function evaluate(view, script) {
    try {
        view.evaluate_javascript(script, -1, null, null, null, (_view, result) => {
            try {
                view.evaluate_javascript_finish(result);
            } catch (error) {
                printerr(`Circle to Search script failed: ${error}`);
            }
        });
    } catch (error) {
        printerr(`Circle to Search script failed: ${error}`);
    }
}

const SOURCE = `
(function () {
    if (window.__ctsWatch)
        return;
    window.__ctsWatch = true;
    const ask = () => {
        if (!location.hostname.endsWith('gemini.google.com'))
            return;
        const box = document.querySelector('div.ql-editor')
            || document.querySelector('rich-textarea [contenteditable="true"]')
            || document.querySelector('[aria-label="Enter a prompt here"]')
            || document.querySelector('[contenteditable="true"][role="textbox"]');
        if (!box)
            return;
        box.focus();
        if (!window.__ctsAsked) {
            window.__ctsAsked = true;
            window.webkit.messageHandlers.cts.postMessage('paste');
        }
    };
    setInterval(ask, 400);
})();
`;

const SUBMIT = `
(() => {
    if (window.__ctsDone)
        return;
    const box = document.querySelector('div.ql-editor')
        || document.querySelector('rich-textarea [contenteditable="true"]')
        || document.querySelector('[aria-label="Enter a prompt here"]')
        || document.querySelector('[contenteditable="true"][role="textbox"]');
    const button = document.querySelector('button.send-button')
        || document.querySelector('button[aria-label="Send message"]')
        || document.querySelector('button[aria-label*="Send" i]');
    if (!button)
        return;
    const disabled = button.disabled || button.getAttribute('aria-disabled') === 'true';
    if (disabled) {
        if (box && !(box.innerText || '').trim() && !window.__ctsPrompted) {
            window.__ctsPrompted = true;
            box.focus();
            document.execCommand('insertText', false, 'What is this?');
        }
        return;
    }
    button.click();
    window.__ctsDone = true;
})();
`;

app.run([imports.system.programInvocationName]);
