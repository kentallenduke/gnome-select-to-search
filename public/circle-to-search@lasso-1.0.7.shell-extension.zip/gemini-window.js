#!/usr/bin/env gjs
// Standalone Gemini window. This is not a browser.

imports.gi.versions.Gtk = '4.0';
imports.gi.versions.Gdk = '4.0';

const {GLib, Gio, Gtk, Gdk} = imports.gi;

const GEMINI = 'https://gemini.google.com/app';
const imagePath = ARGV[0] || '';

GLib.set_prgname('Gemini');

const app = new Gtk.Application({
    application_id: 'org.gnome.circle_to_search.Gemini',
    flags: Gio.ApplicationFlags.NON_UNIQUE,
});

app.connect('activate', () => {
    const win = new Gtk.ApplicationWindow({
        application: app,
        title: 'Gemini',
        default_width: 1040,
        default_height: 760,
    });
    const status = new Gtk.Label({
        label: 'Opening Gemini…',
        wrap: true,
        margin_top: 24,
        margin_bottom: 24,
        margin_start: 24,
        margin_end: 24,
    });
    win.set_child(status);
    win.present();

    try {
        openGemini(win, status);
    } catch (error) {
        printerr(error);
        status.set_label(`Gemini could not open.\n\n${error}`);
    }
});

function openGemini(win, status) {
    imports.gi.versions.WebKit = '6.0';
    let WebKit;
    try {
        WebKit = imports.gi.WebKit;
    } catch (error) {
        status.set_label(
            'This window needs WebKitGTK 6.\nInstall gir1.2-webkit-6.0 or webkitgtk6.0, then try again.\n\n' +
            error);
        return;
    }

    let manager = null;
    try {
        manager = new WebKit.UserContentManager();
        try {
            manager.register_script_message_handler('cts', null);
        } catch (error) {
            manager.register_script_message_handler('cts');
        }
        manager.add_script(new WebKit.UserScript(
            WATCH,
            WebKit.UserContentInjectedFrames.TOP_FRAME,
            WebKit.UserScriptInjectionTime.END,
            null,
            null));
    } catch (error) {
        printerr(`Circle to Search: user script skipped: ${error}`);
        manager = null;
    }

    const session = WebKit.NetworkSession.get_default();
    const view = manager
        ? new WebKit.WebView({
            network_session: session,
            user_content_manager: manager,
        })
        : new WebKit.WebView({network_session: session});

    try {
        view.get_settings().set_user_agent(
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36');
    } catch (error) {
        printerr(error);
    }

    win.set_child(view);
    let pasted = false;

    const pasteOnce = () => {
        if (pasted || !imagePath)
            return;
        pasted = true;
        win.present();
        view.grab_focus();
        putImageOnClipboard(imagePath);
        evaluate(view, FOCUS);
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 250, () => {
            putImageOnClipboard(imagePath);
            try {
                view.execute_editing_command('Paste');
            } catch (error) {
                printerr(`Circle to Search paste failed: ${error}`);
            }
            let tries = 0;
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 450, () => {
                tries += 1;
                evaluate(view, SUBMIT);
                return tries < 18 ? GLib.SOURCE_CONTINUE : GLib.SOURCE_REMOVE;
            });
            return GLib.SOURCE_REMOVE;
        });
    };

    if (manager) {
        try {
            manager.connect('script-message-received::cts', () => pasteOnce());
        } catch (error) {
            printerr(error);
        }
    }

    view.connect('load-changed', (_view, event) => {
        if (event !== WebKit.LoadEvent.FINISHED)
            return;
        const uri = view.get_uri() || '';
        if (!uri.includes('gemini.google.com'))
            return;
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1200, () => {
            pasteOnce();
            return GLib.SOURCE_REMOVE;
        });
    });

    view.load_uri(GEMINI);
}

function putImageOnClipboard(path) {
    try {
        const texture = Gdk.Texture.new_from_filename(path);
        Gdk.Display.get_default().get_clipboard().set_content(
            Gdk.ContentProvider.new_for_value(texture));
    } catch (error) {
        printerr(`Circle to Search clipboard failed: ${error}`);
    }
}

function evaluate(view, script) {
    try {
        view.evaluate_javascript(script, -1, null, null, null, (_view, result) => {
            try {
                view.evaluate_javascript_finish(result);
            } catch (error) {
                printerr(error);
            }
        });
    } catch (error) {
        printerr(error);
    }
}

const FOCUS = `
(() => {
    const box = document.querySelector('div.ql-editor')
        || document.querySelector('rich-textarea [contenteditable="true"]')
        || document.querySelector('[aria-label="Enter a prompt here"]')
        || document.querySelector('[contenteditable="true"][role="textbox"]');
    if (box)
        box.focus();
})();
`;

const WATCH = `
(function () {
    if (window.__ctsWatch)
        return;
    window.__ctsWatch = true;
    setInterval(() => {
        if (!location.hostname.endsWith('gemini.google.com') || window.__ctsAsked)
            return;
        const box = document.querySelector('div.ql-editor')
            || document.querySelector('rich-textarea [contenteditable="true"]')
            || document.querySelector('[aria-label="Enter a prompt here"]')
            || document.querySelector('[contenteditable="true"][role="textbox"]');
        if (!box)
            return;
        box.focus();
        window.__ctsAsked = true;
        try {
            window.webkit.messageHandlers.cts.postMessage('paste');
        } catch (error) {}
    }, 400);
})();
`;

const SUBMIT = `
(() => {
    if (window.__ctsDone)
        return;
    const box = document.querySelector('div.ql-editor')
        || document.querySelector('rich-textarea [contenteditable="true"]')
        || document.querySelector('[aria-label="Enter a prompt here"]')
        || document.querySelector('[contenteditable="true"][role="textbox"]');
    const button = document.querySelector('button.send-button')
        || document.querySelector('button[aria-label="Send message"]')
        || document.querySelector('button[aria-label*="Send" i]');
    if (!button)
        return;
    const disabled = button.disabled || button.getAttribute('aria-disabled') === 'true';
    if (disabled) {
        if (box && !(box.innerText || '').trim() && !window.__ctsPrompted) {
            window.__ctsPrompted = true;
            box.focus();
            document.execCommand('insertText', false, 'What is this?');
        }
        return;
    }
    button.click();
    window.__ctsDone = true;
})();
`;

app.run(['gemini-window']);
