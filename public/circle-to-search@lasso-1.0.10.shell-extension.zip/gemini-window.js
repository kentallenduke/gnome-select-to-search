#!/usr/bin/env gjs
// Resident helper. One process, one saved login, a bottom sheet.

imports.gi.versions.Gtk = '4.0';
imports.gi.versions.Gdk = '4.0';

const {GLib, Gio, Gtk, Gdk} = imports.gi;

const GEMINI = 'https://gemini.google.com/app';

GLib.set_prgname('circle-to-search-gemini');

const app = new Gtk.Application({
    application_id: 'org.gnome.circle_to_search.GeminiMenu',
    flags: Gio.ApplicationFlags.HANDLES_COMMAND_LINE,
});

let win = null;
let view = null;
let imagePath = '';
let searchId = 0;

app.connect('startup', () => app.hold());

app.connect('command-line', (application, commandLine) => {
    const next = imageArg(commandLine.get_arguments());
    try {
        if (!win)
            build(application);
        if (next)
            submitImage(next);
        else
            reveal();
    } catch (error) {
        printerr(error);
        if (win)
            showError(String(error));
    }
    return 0;
});

function imageArg(args) {
    for (let i = args.length - 1; i >= 0; i--) {
        const arg = args[i] || '';
        if (arg.endsWith('.png'))
            return arg;
    }
    return '';
}

function build(application) {
    win = new Gtk.ApplicationWindow({
        application,
        title: 'Gemini',
        decorated: false,
        resizable: true,
    });
    win.add_css_class('cts-sheet');
    installCss();
    anchorTopRight(win);

    const menu = new Gtk.Box({
        orientation: Gtk.Orientation.VERTICAL,
        spacing: 6,
    });
    menu.add_css_class('cts-menu');
    const bar = new Gtk.Box({orientation: Gtk.Orientation.HORIZONTAL});
    const spacer = new Gtk.Box({hexpand: true});
    const close = new Gtk.Button({icon_name: 'window-close-symbolic'});
    close.add_css_class('cts-close');
    close.add_css_class('flat');
    close.connect('clicked', () => win.hide());
    bar.append(spacer);
    bar.append(close);

    const clip = new Gtk.Box({orientation: Gtk.Orientation.VERTICAL});
    clip.add_css_class('cts-clip');
    clip.set_overflow(Gtk.Overflow.HIDDEN);
    clip.set_vexpand(true);
    clip.set_hexpand(true);
    menu.append(bar);
    menu.append(clip);
    win._root = menu;
    win._clip = clip;
    win.set_child(menu);

    const keys = new Gtk.EventControllerKey();
    keys.connect('key-pressed', (_controller, keyval) => {
        if (keyval === Gdk.KEY_Escape) {
            win.hide();
            return true;
        }
        return false;
    });
    win.add_controller(keys);
    win.connect('close-request', () => {
        win.hide();
        return true;
    });

    try {
        view = makeView();
        view.set_vexpand(true);
        view.set_hexpand(true);
        win._clip.append(view);
        view.load_uri(GEMINI);
    } catch (error) {
        printerr(error);
        showError(String(error));
    }
    reveal();
}

function showError(message) {
    const label = new Gtk.Label({
        label: message,
        wrap: true,
        margin_top: 12,
        margin_bottom: 16,
        margin_start: 16,
        margin_end: 16,
    });
    label.set_vexpand(true);
    win._root.append(label);
}

function reveal() {
    const geo = monitorGeometry();
    const height = Math.min(760, Math.max(560, geo.height - 88));
    win.set_default_size(432, height);
    win.present();
}

function monitorGeometry() {
    try {
        const monitors = Gdk.Display.get_default().get_monitors();
        let best = null;
        let area = 0;
        for (let i = 0; i < monitors.get_n_items(); i++) {
            const geo = monitors.get_item(i).get_geometry();
            if (geo.width * geo.height > area) {
                best = geo;
                area = geo.width * geo.height;
            }
        }
        if (best)
            return best;
    } catch (error) {
        printerr(error);
    }
    return {width: 1280, height: 800};
}

function anchorTopRight(window) {
    try {
        imports.gi.versions.Gtk4LayerShell = '1.0';
        const Layer = imports.gi.Gtk4LayerShell;
        Layer.init_for_window(window);
        Layer.set_layer(window, Layer.Layer.OVERLAY);
        Layer.set_anchor(window, Layer.Edge.TOP, true);
        Layer.set_anchor(window, Layer.Edge.RIGHT, true);
        Layer.set_anchor(window, Layer.Edge.LEFT, false);
        Layer.set_anchor(window, Layer.Edge.BOTTOM, false);
        Layer.set_margin(window, Layer.Edge.TOP, 44);
        Layer.set_margin(window, Layer.Edge.RIGHT, 8);
        Layer.set_keyboard_mode(window, Layer.KeyboardMode.ON_DEMAND);
        Layer.set_namespace(window, 'circle-to-search');
    } catch (error) {
        printerr(`Circle to Search: top-right anchor unavailable: ${error}`);
    }
}

function makeView() {
    imports.gi.versions.WebKit = '6.0';
    const WebKit = imports.gi.WebKit;
    const dataDir = GLib.build_filenamev([
        GLib.get_user_data_dir(), 'circle-to-search', 'gemini']);
    const cacheDir = GLib.build_filenamev([
        GLib.get_user_cache_dir(), 'circle-to-search', 'gemini']);
    GLib.mkdir_with_parents(dataDir, 0o700);
    GLib.mkdir_with_parents(cacheDir, 0o700);

    let session;
    try {
        session = new WebKit.NetworkSession({
            data_directory: dataDir,
            cache_directory: cacheDir,
        });
    } catch (error) {
        session = new WebKit.NetworkSession(dataDir, cacheDir);
    }
    try {
        session.set_itp_enabled(false);
    } catch (error) {
        printerr(error);
    }
    try {
        session.set_persistent_credential_storage_enabled(true);
    } catch (error) {
        printerr(error);
    }
    const cookies = session.get_cookie_manager();
    cookies.set_persistent_storage(
        GLib.build_filenamev([dataDir, 'cookies.sqlite']),
        WebKit.CookiePersistentStorage.SQLITE);
    try {
        cookies.set_accept_policy(WebKit.CookieAcceptPolicy.ALWAYS);
    } catch (error) {
        printerr(error);
    }

    const manager = new WebKit.UserContentManager();
    const webView = new WebKit.WebView({
        network_session: session,
        user_content_manager: manager,
    });
    try {
        webView.get_settings().set_user_agent(
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36');
    } catch (error) {
        printerr(error);
    }
    webView.connect('run-file-chooser', (_webView, request) => {
        try {
            if (imagePath)
                request.select_files([imagePath]);
            else
                request.cancel();
        } catch (error) {
            printerr(error);
            try {
                request.cancel();
            } catch (cancelError) {
                printerr(cancelError);
            }
        }
        return true;
    });
    webView.connect('load-changed', (_view, event) => {
        if (!WebKit.LoadEvent || event !== WebKit.LoadEvent.FINISHED)
            return;
        const uri = webView.get_uri() || '';
        if (uri.includes('gemini.google.com') && imagePath)
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 600, () => {
                drive(searchId);
                return GLib.SOURCE_REMOVE;
            });
    });
    webView._webkit = WebKit;
    return webView;
}

function submitImage(path) {
    imagePath = path;
    const id = ++searchId;
    reveal();
    if (!view)
        return;
    evaluate(RESET);
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, 200, () => {
        drive(id);
        return GLib.SOURCE_REMOVE;
    });
}

function drive(id) {
    if (id !== searchId || !view || !imagePath)
        return;
    if (drive._id !== id) {
        drive._id = id;
        drive._started = Date.now();
        drive._pastes = 0;
        drive._lastPaste = 0;
    }
    if (Date.now() - drive._started > 20000)
        return;
    evalText(PROBE, status => {
        if (id !== searchId)
            return;
        const state = String(status || '').replace(/"/g, '').trim();
        if (state === 'sent' || state === 'away') {
            if (state === 'away')
                schedule(id, 500);
            return;
        }
        if (state === 'focus' &&
            drive._pastes < 6 &&
            Date.now() - drive._lastPaste > 800) {
            drive._pastes += 1;
            drive._lastPaste = Date.now();
            putImageOnClipboard(imagePath);
            view.grab_focus();
            try {
                view.execute_editing_command('Paste');
            } catch (error) {
                printerr(`Circle to Search paste failed: ${error}`);
            }
        }
        schedule(id, 400);
    });
}

function schedule(id, delay) {
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, delay, () => {
        drive(id);
        return GLib.SOURCE_REMOVE;
    });
}

function putImageOnClipboard(path) {
    try {
        const file = Gio.File.new_for_path(path);
        const bytes = file.load_bytes(null)[0];
        const png = Gdk.ContentProvider.new_for_bytes('image/png', bytes);
        let provider = png;
        try {
            const texture = Gdk.Texture.new_from_filename(path);
            provider = Gdk.ContentProvider.new_union([
                png,
                Gdk.ContentProvider.new_for_value(texture),
            ]);
        } catch (error) {
            printerr(error);
        }
        Gdk.Display.get_default().get_clipboard().set_content(provider);
    } catch (error) {
        printerr(`Circle to Search clipboard failed: ${error}`);
    }
}

function evaluate(script) {
    evalText(script, () => {});
}

function evalText(script, done) {
    if (!view) {
        done('');
        return;
    }
    try {
        view.evaluate_javascript(script, -1, null, null, null, (_view, result) => {
            let text = '';
            try {
                const value = view.evaluate_javascript_finish(result);
                if (value && typeof value.to_string === 'function')
                    text = value.to_string();
                else if (value != null)
                    text = String(value);
            } catch (error) {
                printerr(error);
            }
            done(text);
        });
    } catch (error) {
        printerr(error);
        done('');
    }
}

function installCss() {
    const dark = shellDark();
    const provider = new Gtk.CssProvider();
    provider.load_from_string(dark ? CSS_DARK : CSS_LIGHT);
    Gtk.StyleContext.add_provider_for_display(
        Gdk.Display.get_default(),
        provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION);
}

function shellDark() {
    try {
        imports.gi.versions.Adw = '1';
        return imports.gi.Adw.StyleManager.get_default().get_dark();
    } catch (error) {
        try {
            return Boolean(Gtk.Settings.get_default().gtk_application_prefer_dark_theme);
        } catch (fallback) {
            return true;
        }
    }
}

const CSS_LIGHT = `
window.cts-sheet { background-color: transparent; }
.cts-menu {
  background-color: #ffffff;
  color: #1e1e1e;
  border-radius: 18px;
  border: 1px solid rgba(0, 0, 0, 0.12);
  padding: 8px;
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.16);
}
.cts-clip { border-radius: 12px; background-color: #ffffff; }
button.cts-close {
  min-width: 28px;
  min-height: 28px;
  padding: 0;
  margin: 0 0 2px;
  border-radius: 999px;
  background: transparent;
  color: #5e5c64;
}
button.cts-close:hover { background: rgba(0, 0, 0, 0.06); }
`;

const CSS_DARK = `
window.cts-sheet { background-color: transparent; }
.cts-menu {
  background-color: #303030;
  color: #ffffff;
  border-radius: 18px;
  border: 1px solid rgba(255, 255, 255, 0.08);
  padding: 8px;
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.28);
}
.cts-clip { border-radius: 12px; background-color: #242424; }
button.cts-close {
  min-width: 28px;
  min-height: 28px;
  padding: 0;
  margin: 0 0 2px;
  border-radius: 999px;
  background: transparent;
  color: #deddda;
}
button.cts-close:hover { background: rgba(255, 255, 255, 0.08); }
`;

const RESET = 'window.__ctsDone = false; window.__ctsPrompted = false; window.__ctsFileTried = false;';

const PROBE = `
(() => {
    function walk(fn) {
        const stack = [document];
        const seen = new Set();
        while (stack.length) {
            const node = stack.pop();
            if (!node || seen.has(node))
                continue;
            seen.add(node);
            fn(node);
            let all = [];
            try {
                all = node.querySelectorAll ? node.querySelectorAll('*') : [];
            } catch (error) {}
            for (const el of all) {
                if (el.shadowRoot)
                    stack.push(el.shadowRoot);
            }
        }
    }
    function deepQuery(selector) {
        let found = null;
        walk(node => {
            if (found || !node.querySelector)
                return;
            try {
                found = node.querySelector(selector);
            } catch (error) {}
        });
        return found;
    }
    function deepAll(selector) {
        const out = [];
        walk(node => {
            if (!node.querySelectorAll)
                return;
            try {
                node.querySelectorAll(selector).forEach(el => out.push(el));
            } catch (error) {}
        });
        return out;
    }
    if (!(location.hostname || '').endsWith('gemini.google.com'))
        return 'away';
    if (window.__ctsDone)
        return 'sent';
    const box = deepQuery('[contenteditable="true"]')
        || deepQuery('textarea')
        || deepQuery('div.ql-editor');
    if (box)
        box.focus();
    const attached = !!(
        deepQuery('img[src^="blob:"]')
        || deepQuery('button[aria-label*="Remove file" i]')
        || deepQuery('button[aria-label*="Remove image" i]')
        || deepQuery('button[aria-label*="Remove attachment" i]')
    );
    const button = deepAll('button').find(item => {
        const label = ((item.getAttribute('aria-label') || '') + ' ' + (item.innerText || '')).toLowerCase();
        return label.includes('send') && !label.includes('feedback');
    });
    if (attached && button && !button.disabled && button.getAttribute('aria-disabled') !== 'true') {
        button.click();
        window.__ctsDone = true;
        return 'sent';
    }
    if (!attached && !window.__ctsFileTried) {
        const file = deepQuery('input[type="file"]');
        if (file) {
            window.__ctsFileTried = true;
            file.click();
            return 'upload';
        }
    }
    if (!attached)
        return box ? 'focus' : 'wait';
    if (box && !(box.innerText || '').trim() && !window.__ctsPrompted) {
        window.__ctsPrompted = true;
        box.focus();
        document.execCommand('insertText', false, 'What is this?');
        return 'typed';
    }
    return 'wait';
})()
`;

const invocation = [imports.system.programInvocationName || 'gemini-window'];
if (ARGV[0])
    invocation.push(ARGV[0]);
app.run(invocation);
