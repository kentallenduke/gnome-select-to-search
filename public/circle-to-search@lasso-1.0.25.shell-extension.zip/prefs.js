// SPDX-License-Identifier: GPL-2.0-or-later

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class CircleToSearchPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const page = new Adw.PreferencesPage({
            title: 'Circle to Search',
            icon_name: 'edit-find-symbolic',
        });
        window.add(page);

        const group = new Adw.PreferencesGroup();
        page.add(group);

        const topBar = new Adw.SwitchRow({
            title: 'Show in the top bar',
            subtitle: 'Adds a Circle to Search button next to the other status icons',
        });
        this.getSettings().bind(
            'show-top-bar',
            topBar,
            'active',
            Gio.SettingsBindFlags.DEFAULT);
        group.add(topBar);
    }
}
