#!/usr/bin/env gjs
// Resident helper. One process, one saved login, a bottom sheet.

imports.gi.versions.Gtk = '4.0';
imports.gi.versions.Gdk = '4.0';

const {GLib, Gio, Gtk, Gdk} = imports.gi;

const GEMINI = 'https://gemini.google.com/app';

GLib.set_prgname('circle-to-search-gemini');

const app = new Gtk.Application({
    application_id: 'org.gnome.circle_to_search.Gemini',
    flags: Gio.ApplicationFlags.HANDLES_COMMAND_LINE,
});

let win = null;
let view = null;
let imagePath = '';
let pasteGen = 0;
let pastedFor = -1;

app.connect('startup', () => app.hold());

app.connect('command-line', (application, commandLine) => {
    const next = imageArg(commandLine.get_arguments());
    try {
        if (!win)
            build(application);
        if (next)
            submitImage(next);
        else
            reveal();
    } catch (error) {
        printerr(error);
        if (win)
            showError(String(error));
    }
    return 0;
});

function imageArg(args) {
    for (let i = args.length - 1; i >= 0; i--) {
        const arg = args[i] || '';
        if (arg.endsWith('.png'))
            return arg;
    }
    return '';
}

function build(application) {
    win = new Gtk.ApplicationWindow({
        application,
        title: 'Gemini',
        decorated: false,
        resizable: true,
    });
    win.add_css_class('cts-sheet');
    installCss();
    anchorBottom(win);

    const root = new Gtk.Box({
        orientation: Gtk.Orientation.VERTICAL,
        spacing: 0,
    });
    const handle = new Gtk.Label({label: ''});
    handle.add_css_class('cts-handle');
    handle.set_halign(Gtk.Align.CENTER);

    const head = new Gtk.Box({
        orientation: Gtk.Orientation.HORIZONTAL,
        spacing: 12,
    });
    head.add_css_class('cts-head');
    const titles = new Gtk.Box({
        orientation: Gtk.Orientation.VERTICAL,
        spacing: 2,
        hexpand: true,
    });
    const kicker = new Gtk.Label({label: 'CIRCLE TO SEARCH', xalign: 0});
    kicker.add_css_class('cts-kicker');
    const title = new Gtk.Label({label: 'Gemini', xalign: 0});
    title.add_css_class('cts-title');
    titles.append(kicker);
    titles.append(title);
    const close = new Gtk.Button({label: 'Close'});
    close.add_css_class('cts-close');
    close.connect('clicked', () => win.hide());
    head.append(titles);
    head.append(close);

    root.append(handle);
    root.append(head);
    win._root = root;
    win.set_child(root);
    win.connect('close-request', () => {
        win.hide();
        return true;
    });

    try {
        view = makeView();
        view.set_vexpand(true);
        view.set_hexpand(true);
        root.append(view);
        view.load_uri(GEMINI);
    } catch (error) {
        printerr(error);
        showError(String(error));
    }
    reveal();
}

function showError(message) {
    const label = new Gtk.Label({
        label: message,
        wrap: true,
        margin_top: 12,
        margin_bottom: 16,
        margin_start: 16,
        margin_end: 16,
    });
    label.set_vexpand(true);
    win._root.append(label);
}

function reveal() {
    const geo = monitorGeometry();
    const height = Math.max(420, Math.round(geo.height * 0.62));
    win.set_default_size(Math.min(860, geo.width - 36), height);
    win.present();
}

function monitorGeometry() {
    try {
        const monitors = Gdk.Display.get_default().get_monitors();
        let best = null;
        let area = 0;
        for (let i = 0; i < monitors.get_n_items(); i++) {
            const geo = monitors.get_item(i).get_geometry();
            if (geo.width * geo.height > area) {
                best = geo;
                area = geo.width * geo.height;
            }
        }
        if (best)
            return best;
    } catch (error) {
        printerr(error);
    }
    return {width: 1280, height: 800};
}

function anchorBottom(window) {
    const namespaces = ['Gtk4LayerShell'];
    for (const name of namespaces) {
        try {
            imports.gi.versions[name] = '1.0';
            const Layer = imports.gi[name];
            Layer.init_for_window(window);
            Layer.set_layer(window, Layer.Layer.OVERLAY);
            Layer.set_anchor(window, Layer.Edge.BOTTOM, true);
            Layer.set_anchor(window, Layer.Edge.LEFT, true);
            Layer.set_anchor(window, Layer.Edge.RIGHT, true);
            Layer.set_margin(window, Layer.Edge.BOTTOM, 16);
            Layer.set_margin(window, Layer.Edge.LEFT, 18);
            Layer.set_margin(window, Layer.Edge.RIGHT, 18);
            Layer.set_keyboard_mode(window, Layer.KeyboardMode.ON_DEMAND);
            Layer.set_namespace(window, 'circle-to-search');
            return;
        } catch (error) {
            printerr(`Circle to Search: no ${name}: ${error}`);
        }
    }
}

function makeView() {
    imports.gi.versions.WebKit = '6.0';
    const WebKit = imports.gi.WebKit;
    const dataDir = GLib.build_filenamev([
        GLib.get_user_data_dir(), 'circle-to-search', 'gemini']);
    const cacheDir = GLib.build_filenamev([
        GLib.get_user_cache_dir(), 'circle-to-search', 'gemini']);
    GLib.mkdir_with_parents(dataDir, 0o700);
    GLib.mkdir_with_parents(cacheDir, 0o700);

    let session;
    try {
        session = new WebKit.NetworkSession({
            data_directory: dataDir,
            cache_directory: cacheDir,
        });
    } catch (error) {
        session = new WebKit.NetworkSession(dataDir, cacheDir);
    }
    try {
        session.set_itp_enabled(false);
    } catch (error) {
        printerr(error);
    }
    try {
        session.set_persistent_credential_storage_enabled(true);
    } catch (error) {
        printerr(error);
    }
    const cookies = session.get_cookie_manager();
    cookies.set_persistent_storage(
        GLib.build_filenamev([dataDir, 'cookies.sqlite']),
        WebKit.CookiePersistentStorage.SQLITE);
    try {
        cookies.set_accept_policy(WebKit.CookieAcceptPolicy.ALWAYS);
    } catch (error) {
        printerr(error);
    }

    const manager = new WebKit.UserContentManager();
    try {
        manager.register_script_message_handler('cts', null);
    } catch (error) {
        manager.register_script_message_handler('cts');
    }
    manager.add_script(new WebKit.UserScript(
        WATCH,
        WebKit.UserContentInjectedFrames.TOP_FRAME,
        WebKit.UserScriptInjectionTime.END,
        null,
        null));
    try {
        manager.connect('script-message-received::cts', () => pasteOnce());
    } catch (error) {
        printerr(error);
    }

    const webView = new WebKit.WebView({
        network_session: session,
        user_content_manager: manager,
    });
    try {
        webView.get_settings().set_user_agent(
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36');
    } catch (error) {
        printerr(error);
    }
    webView.connect('load-changed', (_view, event) => {
        if (!WebKit.LoadEvent || event !== WebKit.LoadEvent.FINISHED)
            return;
        const uri = webView.get_uri() || '';
        if (uri.includes('gemini.google.com') && imagePath)
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 900, () => {
                pasteOnce();
                return GLib.SOURCE_REMOVE;
            });
    });
    webView._webkit = WebKit;
    return webView;
}

function submitImage(path) {
    imagePath = path;
    pasteGen += 1;
    reveal();
    if (!view)
        return;
    evaluate('window.__ctsDone = false; window.__ctsAsked = false; window.__ctsPrompted = false;');
    const uri = view.get_uri() || '';
    if (uri.includes('gemini.google.com'))
        pasteOnce();
}

function pasteOnce() {
    if (!view || !imagePath || pastedFor === pasteGen)
        return;
    pastedFor = pasteGen;
    const gen = pasteGen;
    reveal();
    view.grab_focus();
    putImageOnClipboard(imagePath);
    evaluate(FOCUS);
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, 250, () => {
        if (gen !== pasteGen)
            return GLib.SOURCE_REMOVE;
        putImageOnClipboard(imagePath);
        try {
            view.execute_editing_command('Paste');
        } catch (error) {
            printerr(`Circle to Search paste failed: ${error}`);
        }
        let tries = 0;
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 450, () => {
            if (gen !== pasteGen)
                return GLib.SOURCE_REMOVE;
            tries += 1;
            evaluate(SUBMIT);
            return tries < 18 ? GLib.SOURCE_CONTINUE : GLib.SOURCE_REMOVE;
        });
        return GLib.SOURCE_REMOVE;
    });
}

function putImageOnClipboard(path) {
    try {
        const texture = Gdk.Texture.new_from_filename(path);
        Gdk.Display.get_default().get_clipboard().set_content(
            Gdk.ContentProvider.new_for_value(texture));
    } catch (error) {
        printerr(`Circle to Search clipboard failed: ${error}`);
    }
}

function evaluate(script) {
    if (!view)
        return;
    try {
        view.evaluate_javascript(script, -1, null, null, null, (_view, result) => {
            try {
                view.evaluate_javascript_finish(result);
            } catch (error) {
                printerr(error);
            }
        });
    } catch (error) {
        printerr(error);
    }
}

function installCss() {
    const provider = new Gtk.CssProvider();
    provider.load_from_string(CSS);
    Gtk.StyleContext.add_provider_for_display(
        Gdk.Display.get_default(),
        provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION);
}

const CSS = `
window.cts-sheet {
  background-color: #fffcf9;
  border-radius: 18px;
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.35);
}
.cts-handle {
  min-width: 36px;
  min-height: 4px;
  margin-top: 10px;
  margin-bottom: 8px;
  border-radius: 999px;
  background-color: rgba(36, 31, 49, 0.22);
}
.cts-head {
  margin: 0 16px 8px;
}
.cts-kicker {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.08em;
  color: #5e5c64;
}
.cts-title {
  font-size: 18px;
  font-weight: 700;
  color: #241f31;
}
button.cts-close {
  border-radius: 999px;
  padding: 6px 14px;
  background-color: rgba(36, 31, 49, 0.08);
  color: #241f31;
  font-weight: 600;
}
`;

const FOCUS = `
(() => {
    const box = document.querySelector('div.ql-editor')
        || document.querySelector('rich-textarea [contenteditable="true"]')
        || document.querySelector('[aria-label="Enter a prompt here"]')
        || document.querySelector('[contenteditable="true"][role="textbox"]');
    if (box)
        box.focus();
})();
`;

const WATCH = `
(function () {
    if (window.__ctsWatch)
        return;
    window.__ctsWatch = true;
    setInterval(() => {
        if (!location.hostname.endsWith('gemini.google.com') || window.__ctsAsked)
            return;
        const box = document.querySelector('div.ql-editor')
            || document.querySelector('rich-textarea [contenteditable="true"]')
            || document.querySelector('[aria-label="Enter a prompt here"]')
            || document.querySelector('[contenteditable="true"][role="textbox"]');
        if (!box)
            return;
        box.focus();
        window.__ctsAsked = true;
        try {
            window.webkit.messageHandlers.cts.postMessage('paste');
        } catch (error) {}
    }, 400);
})();
`;

const SUBMIT = `
(() => {
    if (window.__ctsDone)
        return;
    const box = document.querySelector('div.ql-editor')
        || document.querySelector('rich-textarea [contenteditable="true"]')
        || document.querySelector('[aria-label="Enter a prompt here"]')
        || document.querySelector('[contenteditable="true"][role="textbox"]');
    const button = document.querySelector('button.send-button')
        || document.querySelector('button[aria-label="Send message"]')
        || document.querySelector('button[aria-label*="Send" i]');
    if (!button)
        return;
    const disabled = button.disabled || button.getAttribute('aria-disabled') === 'true';
    if (disabled) {
        if (box && !(box.innerText || '').trim() && !window.__ctsPrompted) {
            window.__ctsPrompted = true;
            box.focus();
            document.execCommand('insertText', false, 'What is this?');
        }
        return;
    }
    button.click();
    window.__ctsDone = true;
})();
`;

const invocation = [imports.system.programInvocationName || 'gemini-window'];
if (ARGV[0])
    invocation.push(ARGV[0]);
app.run(invocation);
